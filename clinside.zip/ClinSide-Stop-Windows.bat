@echo off
setlocal
cd /d "%~dp0"
if not exist "runtime\python.exe" exit /b 1
"runtime\python.exe" stop_clinside.py
