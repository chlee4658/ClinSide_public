import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
RUNTIME = ROOT / 'runtime'
CONTROL = DATA / 'clinside-server.json'
LOG = DATA / 'clinside-server.log'
NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)


def server_url(info):
    return f"http://127.0.0.1:{int(info['port'])}"


def is_ready(info):
    try:
        with urllib.request.urlopen(server_url(info) + '/api/records', timeout=1):
            return True
    except (OSError, ValueError, KeyError):
        return False


def fail(message):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, 'ClinSide', 0x10)
    except Exception:
        print(message)


def main():
    DATA.mkdir(exist_ok=True)
    python = RUNTIME / 'python.exe'
    server_script = ROOT / 'server.py'
    if not python.is_file() or not server_script.is_file():
        fail('ClinSide 파일이 온전하지 않습니다. ZIP 전체를 새 폴더에 다시 풀어주세요.')
        return 1

    if CONTROL.is_file():
        try:
            info = json.loads(CONTROL.read_text(encoding='utf-8'))
            if is_ready(info):
                webbrowser.open(server_url(info))
                return 0
        except (OSError, ValueError, KeyError):
            pass

    env = os.environ.copy()
    env['CLINSIDE_NO_BROWSER'] = '1'
    try:
        with LOG.open('ab') as log:
            process = subprocess.Popen(
                [str(python), str(server_script)],
                cwd=ROOT,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                env=env,
                creationflags=NO_WINDOW,
            )
    except OSError as exc:
        fail(f'ClinSide를 시작하지 못했습니다.\n{exc}')
        return 1

    for _ in range(60):
        if CONTROL.is_file():
            try:
                info = json.loads(CONTROL.read_text(encoding='utf-8'))
                if is_ready(info):
                    webbrowser.open(server_url(info))
                    return 0
            except (OSError, ValueError, KeyError):
                pass
        if process.poll() is not None:
            break
        time.sleep(0.25)

    try:
        details = LOG.read_text(encoding='utf-8', errors='replace')[-1800:]
    except OSError:
        details = ''
    fail('ClinSide 시작에 실패했습니다.\n\n' + (details or 'Windows에서 실행이 차단되었는지 확인해주세요.'))
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
