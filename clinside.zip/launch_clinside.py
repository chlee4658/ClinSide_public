import json
import hashlib
import os
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP_FILES = ('server.py', 'phrases.html', 'companion.js')
def app_build_id(root):
    digest = hashlib.sha256()
    for name in APP_FILES:
        digest.update(name.encode('utf-8'))
        digest.update((root / name).read_bytes())
    return digest.hexdigest()
FOLDER_ID = hashlib.sha256(str(ROOT).casefold().encode('utf-8')).hexdigest()
BUILD_ID = app_build_id(ROOT)
DATA = ROOT / 'data'
RUNTIME = ROOT / 'runtime'
CONTROL = DATA / 'clinside-server.json'
LOG = DATA / 'clinside-server.log'
NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)


def server_url(info):
    return f"http://127.0.0.1:{int(info['port'])}"


def is_ready(info):
    try:
        with urllib.request.urlopen(server_url(info) + '/api/instance', timeout=1) as response:
            instance = json.load(response)
            return instance.get('folder') == FOLDER_ID and instance.get('build') == BUILD_ID
    except (OSError, ValueError, KeyError):
        return False


def fail(message):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, 'ClinSide', 0x10)
    except Exception:
        print(message)


def open_app(info):
    url = server_url(info)
    try:
        if webbrowser.open(url, new=2):
            return True
        if os.name == 'nt':
            os.startfile(url)
            return True
    except Exception:
        pass
    fail('ClinSide가 실행 중입니다. 브라우저에서 다음 주소를 열어주세요.\n' + url)
    return False


def main():
    DATA.mkdir(exist_ok=True)
    bundled_python = RUNTIME / 'python.exe'
    python = bundled_python if bundled_python.is_file() else Path(sys.executable)
    server_script = ROOT / 'server.py'
    if not python.is_file() or not server_script.is_file():
        fail('ClinSide 파일이 온전하지 않습니다. ZIP 전체를 새 폴더에 다시 풀어주세요.')
        return 1

    if CONTROL.is_file():
        try:
            info = json.loads(CONTROL.read_text(encoding='utf-8'))
            if is_ready(info):
                if not open_app(info):
                    return 1
                return 0
        except (OSError, ValueError, KeyError):
            pass

    env = os.environ.copy()
    env['CLINSIDE_NO_BROWSER'] = '1'
    try:
        with LOG.open('ab') as log:
            process = subprocess.Popen(
                [str(python), str(server_script)],
                cwd=ROOT,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                env=env,
                creationflags=NO_WINDOW,
            )
    except OSError as exc:
        fail(f'ClinSide를 시작하지 못했습니다.\n{exc}')
        return 1

    for _ in range(60):
        if CONTROL.is_file():
            try:
                info = json.loads(CONTROL.read_text(encoding='utf-8'))
                if is_ready(info):
                    if not open_app(info):
                        return 1
                    return 0
            except (OSError, ValueError, KeyError):
                pass
        if process.poll() is not None:
            break
        time.sleep(0.25)

    try:
        details = LOG.read_text(encoding='utf-8', errors='replace')[-1800:]
    except OSError:
        details = ''
    fail('ClinSide 시작에 실패했습니다.\n\n' + (details or 'Windows에서 실행이 차단되었는지 확인해주세요.'))
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
