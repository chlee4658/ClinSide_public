"""Copy the legacy leg-exam SQLite database into ClinSide on request."""
import argparse
import datetime
import os
import sqlite3
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent
DEST = ROOT / "data" / "clinic.sqlite3"
BACKUPS = ROOT / "backups"


def copy_database(source: Path, destination: Path) -> None:
    uri = "file:" + quote(str(source.resolve())) + "?mode=ro"
    with sqlite3.connect(uri, uri=True) as reader:
        with sqlite3.connect(destination) as writer:
            reader.backup(writer)
            if writer.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise RuntimeError("DB 복사 검증에 실패했습니다.")


def main() -> None:
    parser = argparse.ArgumentParser(description="기존 leg-exam DB를 ClinSide로 복사")
    parser.add_argument("source", type=Path, help="기존 clinic.sqlite3 경로")
    args = parser.parse_args()
    source = args.source.resolve()
    if not source.is_file() or source == DEST.resolve():
        parser.error("서로 다른 기존 DB 파일 경로를 지정해주세요.")
    DEST.parent.mkdir(exist_ok=True)
    BACKUPS.mkdir(exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    source_backup = BACKUPS / f"legacy-source-{stamp}.sqlite3"
    dest_backup = BACKUPS / f"companion-before-import-{stamp}.sqlite3"
    staging = DEST.with_suffix(".importing")
    if staging.exists():
        parser.error("이전 작업의 임시 파일이 남아 있습니다. 확인 후 다시 실행해주세요.")
    if DEST.exists():
        with sqlite3.connect(DEST) as db:
            count = db.execute("SELECT COUNT(*) FROM patients").fetchone()[0]
        if count:
            parser.error("대상 DB에 환자 기록이 있어 덮어쓸 수 없습니다.")
        copy_database(DEST, dest_backup)
    try:
        copy_database(source, source_backup)
        copy_database(source, staging)
        os.replace(staging, DEST)
    finally:
        staging.unlink(missing_ok=True)
    print(f"이전 완료. 원본 보존. 원본 백업: {source_backup}")


if __name__ == "__main__":
    main()
