@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" goto missing
"%~dp0runtime\python.exe" "%~dp0launch_clinside.py"
exit /b %errorlevel%
:missing
echo Missing runtime. Extract all files and try again.
pause
exit /b 1
