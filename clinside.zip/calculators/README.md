# ClinSide 계산기

이 폴더에 각 계산기의 독립 실행형 `.html` 또는 `.htm` 파일을 넣으세요. ClinSide가 파일의 `<title>`을 읽어 상단 **계산기** 메뉴의 하위 메뉴에 자동으로 표시합니다.

예시:

```html
<!doctype html>
<html lang="ko">
<head><meta charset="utf-8"><title>계산기 이름</title></head>
<body><!-- 계산기 화면 --></body>
</html>
```

HTML에서 상대 경로로 불러오는 CSS, JavaScript, 이미지 파일도 이 폴더 안에 둘 수 있습니다. 하위 폴더의 HTML 파일도 메뉴에서 찾습니다.
