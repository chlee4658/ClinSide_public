@echo off
setlocal
chcp 65001 >nul
title ClinSide Update
set "APP_DIR=%~dp0"
set "UPDATE_URL=https://github.com/chlee4658/ClinSide_public/raw/refs/heads/main/clinside.zip"

echo ClinSide will be updated from the latest public release.
echo Close the ClinSide browser and stop the local server before continuing.
choice /C YN /M "Continue with update"
if errorlevel 2 goto :cancel

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $app='%APP_DIR%'; $url='%UPDATE_URL%'; $temp=Join-Path $env:TEMP ('ClinSideUpdate-' + [guid]::NewGuid().ToString('N')); $zip=Join-Path $temp 'clinside.zip'; $stage=Join-Path $temp 'stage'; try { New-Item -ItemType Directory -Force -Path $stage | Out-Null; Invoke-WebRequest -Uri $url -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $stage -Force; $source=$stage; if (-not (Test-Path (Join-Path $source 'ClinSide-Windows.bat'))) { $source=(Get-ChildItem -LiteralPath $stage -Directory | Select-Object -First 1).FullName }; if (-not (Test-Path (Join-Path $source 'ClinSide-Windows.bat'))) { throw 'Downloaded package does not contain ClinSide-Windows.bat.' }; $parent=Split-Path $app -Parent; $backup=Join-Path $parent ('ClinSide-before-update-' + (Get-Date -Format 'yyyyMMdd-HHmmss')); New-Item -ItemType Directory -Force -Path $backup | Out-Null; & robocopy $app $backup /E /XD (Join-Path $app 'data') (Join-Path $app 'backups') (Join-Path $app 'runtime') /XF 'Update_ClinSide_Git.bat'; if ($LASTEXITCODE -ge 8) { throw 'Could not create the pre-update backup.' }; Write-Host ('Backup created: ' + $backup); & robocopy $source $app /E /XD (Join-Path $source 'data') (Join-Path $source 'backups') /XF 'Update_ClinSide_Git.bat'; if ($LASTEXITCODE -ge 8) { throw 'File copy failed. Restore the backup if needed.' }; Write-Host 'Update completed.'; } catch { Write-Host ('Update failed: ' + $_.Exception.Message); exit 1 } finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }"
if errorlevel 1 goto :failed

echo.
echo Update complete. Start ClinSide-Windows.bat.
goto :end

:cancel
echo Update cancelled.
goto :end

:failed
echo.
echo Update failed. Check the message above. The pre-update backup folder remains available.
pause
exit /b 1

:end
pause
exit /b 0
