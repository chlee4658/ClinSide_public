#!/usr/bin/env python3
"""Small local server for the ClinSide growth-chart distribution."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit
import html
import json
import os
import re
import secrets
import threading
import webbrowser

ROOT = Path(__file__).resolve().parent
CALCULATORS = ROOT / "calculators"
DATA = ROOT / "data"
CONTROL = DATA / "clinside-server.json"
STOP_TOKEN = secrets.token_urlsafe(32)


def calculator_pages():
    pages = []
    for path in sorted(CALCULATORS.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in (".html", ".htm"):
            continue
        relative = path.relative_to(CALCULATORS)
        if any(part.startswith(".") for part in relative.parts):
            continue
        source = path.read_text(encoding="utf-8", errors="replace")
        match = re.search(r"<title\b[^>]*>(.*?)</title\s*>", source, re.I | re.S)
        title = html.unescape(re.sub(r"<[^>]+>", "", match.group(1))).strip() if match else path.stem
        pages.append({"title": title or path.stem, "url": "/calculators/" + quote(relative.as_posix())})
    return pages


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, *args):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def json_response(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/calculators":
            return self.json_response(calculator_pages())
        if path == "/api/records":
            return self.json_response([])
        if path == "/api/shutdown-token":
            return self.json_response({"token": STOP_TOKEN})
        if path in ("/", "/index.html", "/style.css", "/companion.js", "/assets/clinside_logo.png"):
            return super().do_GET()
        if path.startswith("/embedded/chart/"):
            target = (ROOT / unquote(path.lstrip("/"))).resolve()
            if target.is_relative_to((ROOT / "embedded/chart").resolve()) and target.is_file():
                return super().do_GET()
        if path.startswith("/calculators/"):
            target = (CALCULATORS / unquote(path[len("/calculators/"):])).resolve()
            if target.is_relative_to(CALCULATORS.resolve()) and target.is_file():
                return super().do_GET()
        return self.send_error(404)

    def do_POST(self):
        if urlsplit(self.path).path != "/api/shutdown":
            return self.send_error(404)
        if self.headers.get("X-ClinSide-Token") != STOP_TOKEN:
            return self.send_error(403)
        self.json_response({"ok": True})
        threading.Thread(target=server.shutdown, daemon=True).start()


if __name__ == "__main__":
    DATA.mkdir(exist_ok=True)
    CALCULATORS.mkdir(exist_ok=True)
    for port in range(8765, 8786):
        try:
            server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    else:
        raise SystemExit("사용 가능한 포트가 없습니다.")
    info = {"pid": os.getpid(), "port": server.server_address[1], "token": STOP_TOKEN}
    CONTROL.write_text(json.dumps(info), encoding="utf-8")
    url = f"http://127.0.0.1:{info['port']}"
    print(f"ClinSide 성장도표: {url}", flush=True)
    if os.environ.get("CLINSIDE_NO_BROWSER") != "1":
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        CONTROL.unlink(missing_ok=True)
