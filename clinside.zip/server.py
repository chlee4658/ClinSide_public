#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, webbrowser, threading, hashlib, time
from urllib.parse import urlsplit,parse_qs,quote,unquote
import secrets
import re, html, base64, tempfile, subprocess
from storage import Store
ROOT=Path(__file__).resolve().parent
APP_FILES = ('server.py', 'phrases.html', 'companion.js')
def app_build_id(root):
    digest = hashlib.sha256()
    for name in APP_FILES:
        digest.update(name.encode('utf-8'))
        digest.update((root / name).read_bytes())
    return digest.hexdigest()
FOLDER_ID = hashlib.sha256(str(ROOT).casefold().encode('utf-8')).hexdigest()
BUILD_ID = app_build_id(ROOT)
RECORDS=ROOT/'records'
DATA=ROOT/'data'
DATA.mkdir(exist_ok=True)
AREA_FILE=DATA/'chart-capture-area.json'
LEGACY_AREA_FILE=ROOT/'chart-capture-area.json'
if LEGACY_AREA_FILE.is_file() and not AREA_FILE.exists():
    try:
        legacy_area=json.loads(LEGACY_AREA_FILE.read_text(encoding='utf-8'))
        if (isinstance(legacy_area,dict) and all(type(legacy_area.get(k)) is int for k in ('x','y','width','height'))
                and legacy_area['x']>=0 and legacy_area['y']>=0 and legacy_area['width']>0 and legacy_area['height']>0):
            AREA_FILE.write_text(json.dumps(legacy_area,ensure_ascii=False),encoding='utf-8')
    except (OSError,ValueError,TypeError,json.JSONDecodeError):
        pass
CALCULATORS_DIR=ROOT/'calculators'
CALCULATORS_DIR.mkdir(exist_ok=True)
CONTROL_FILE=DATA/'clinside-server.json'
PHRASES_FILE=DATA/'phrases.json'
PHRASES_LOCK=threading.Lock()
def normalize_phrase_category(category):
    return {'진료 문구':'진료','환자 문자':'메시지'}.get(category,category)

def read_phrases():
    if not PHRASES_FILE.exists():return []
    value=json.loads(PHRASES_FILE.read_text(encoding='utf-8'))
    if not isinstance(value,list):raise ValueError('문구 파일 형식이 올바르지 않습니다.')
    return [{**row,'category':normalize_phrase_category(row.get('category'))} if isinstance(row,dict) else row for row in value]

def validate_phrases(value):
    if not isinstance(value,list) or len(value)>2000:raise ValueError('문구는 최대 2,000개까지 저장할 수 있습니다.')
    result=[];ids=set()
    for row in value:
        if not isinstance(row,dict):raise ValueError('문구 형식이 올바르지 않습니다.')
        pid=row.get('id');category=row.get('category');title=row.get('title');content=row.get('content')
        if not isinstance(pid,str) or not 1<=len(pid)<=100 or pid in ids:raise ValueError('문구 ID가 올바르지 않습니다.')
        category=normalize_phrase_category(category)
        if not isinstance(category,str) or not category.strip() or len(category.strip())>40:raise ValueError('문구 분류는 40자 이내로 입력해주세요.')
        category=category.strip()
        if not isinstance(title,str) or not title.strip() or len(title)>120:raise ValueError('문구 제목을 확인해주세요.')
        if not isinstance(content,str) or not content.strip() or len(content)>10000:raise ValueError('문구 내용을 확인해주세요.')
        ids.add(pid);result.append({'id':pid,'category':category,'title':title.strip(),'content':content})
    return result

def same_origin(handler):
    origin=handler.headers.get('Origin')
    host=handler.headers.get('Host')
    site=handler.headers.get('Sec-Fetch-Site')
    return (not origin or origin==f'http://{host}') and (not site or site in ('same-origin','none'))

STOP_TOKEN=secrets.token_urlsafe(32)

# A streaming connection continues working when Chrome throttles background timers.
PRESENCE_TIMEOUT=20
STARTUP_TIMEOUT=90
class BrowserPresence:
    def __init__(self,clock=time.monotonic):
        self.clock=clock
        self.started=clock()
        self.last_seen=self.started
        self.connected_once=False
        self.lock=threading.Lock()
    def touch(self):
        with self.lock:
            self.connected_once=True
            self.last_seen=self.clock()
    def expired(self):
        with self.lock:
            timeout=PRESENCE_TIMEOUT if self.connected_once else STARTUP_TIMEOUT
            return self.clock()-self.last_seen>timeout

BROWSER_PRESENCE=BrowserPresence()

def monitor_browser_presence(http_server):
    while True:
        time.sleep(2)
        if BROWSER_PRESENCE.expired():
            print('ClinSide: no browser connection; shutting down.',flush=True)
            http_server.shutdown()
            return

def valid_capture_area(value):
    return (isinstance(value,dict)
            and all(type(value.get(key)) is int for key in ('x','y','width','height'))
            and value['x']>=0 and value['y']>=0 and value['width']>0 and value['height']>0)

def calculator_pages():
    pages=[]
    for path in sorted(CALCULATORS_DIR.rglob('*')):
        if not path.is_file() or path.suffix.lower() not in ('.html','.htm'):continue
        if any(part.startswith('.') for part in path.relative_to(CALCULATORS_DIR).parts):continue
        source=path.read_text(encoding='utf-8',errors='replace')
        match=re.search(r'<title\b[^>]*>(.*?)</title\s*>',source,re.IGNORECASE|re.DOTALL)
        title=html.unescape(re.sub(r'<[^>]+>','',match.group(1))).strip() if match else path.stem
        pages.append({'title':title or path.stem,'path':path.relative_to(CALCULATORS_DIR).as_posix(),'url':'/calculators/'+quote(path.relative_to(CALCULATORS_DIR).as_posix())})
    return pages

def parse_inpatient_words(payload):
    """Parse the fixed SenseChart layout; do not guess missing clinical information."""
    from statistics import median
    width=float(payload.get('width',0));height=float(payload.get('height',0))
    if not width or not height:raise ValueError('OCR 이미지 크기가 올바르지 않습니다.')

    def prepare(items):
        words=[]
        for item in items if isinstance(items,list) else []:
            try:
                x=float(item['x']);y=float(item['y']);w=float(item['w']);h=float(item['h'])
                value=str(item['text']).strip()
            except (KeyError,ValueError,TypeError):continue
            if value and w>0 and h>0 and 0<=x<width and 0<=y<height and y+h/2>height*.15:
                words.append({'text':value,'x':x,'cy':y+h/2,'h':h,'w':w})
        return words

    words=prepare(payload.get('words',[]))
    if not words:return []
    typical=median([w['h'] for w in words])
    threshold=max(2.0,min(height*.075,typical*.8))
    groups=[]
    for word in sorted(words,key=lambda x:x['cy']):
        nearest=min(groups,key=lambda g:abs(g['cy']-word['cy'])) if groups else None
        if nearest and abs(nearest['cy']-word['cy'])<=threshold:
            nearest['items'].append(word)
            nearest['cy']=median([x['cy'] for x in nearest['items']])
        else:groups.append({'cy':word['cy'],'items':[word]})
    columns=[('ward',.095,.22),('patient_no',.22,.29),('name',.29,.42),('age',.42,.52),
             ('sex',.52,.57),('admission',.57,.71),('day',.71,.77),('diagnosis',.77,1.01)]
    secondary={key:prepare(value) for key,value in (payload.get('columns') or {}).items()
               if key in ('room','name','age','day','diagnosis')}
    patients=[]
    for row in sorted(groups,key=lambda r:r['cy']):
        fields={name:[] for name,_,_ in columns}
        for word in sorted(row['items'],key=lambda x:x['x']):
            px=(word['x']+min(word['w']/2,width*.015))/width
            for name,left,right in columns:
                if left<=px<right:
                    fields[name].append(word['text']);break
        fields={key:' '.join(val).strip() for key,val in fields.items()}
        if not fields['ward'] and not fields['name']:continue
        if '이름' in fields['name'] or fields['ward'].strip() in ('병동','병실'):continue
        room=re.search(r'(?<!\d)(\d{3,4})(?!\d)',fields['ward'])
        room_text=room.group(1)[-3:] if room else ''
        if not room_text and not any(fields[k] for k in ('name','age','diagnosis')):continue

        # Read each column independently to avoid neighboring-column contamination.
        # The crop OCR's word positions are expressed in original-image coordinates.
        cropped={}
        for key in ('room','name','age','day','diagnosis'):
            candidates=[w for w in secondary.get(key,[]) if abs(w['cy']-row['cy'])<=max(5.0,typical*1.25)]
            cropped[key]=' '.join(w['text'] for w in sorted(candidates,key=lambda w:w['x'])).strip()

        room_crop=re.search(r'(?<!\d)(\d{3,4})(?!\d)',cropped.get('room',''))
        if room_crop:room_text=room_crop.group(1)[-3:]

        # Row-specific OCR isolates small values from grid lines and nearby cells.
        row_matches=[item for item in payload.get('rowReadings',[])
                     if isinstance(item,dict) and isinstance(item.get('cy'),(int,float))
                     and abs(item['cy']-row['cy'])<=max(5.0,typical*1.25)]
        row_reading=min(row_matches,key=lambda item:abs(item['cy']-row['cy'])) if row_matches else {}
        def clean_name(value):
            value=re.sub(r'^[\s*+•·.]+|[\s*+•·.]+$','',value)
            return re.sub(r'\s+','',value)
        # Use the per-row retry as a third, independent OCR reading.
        row_candidates=[item for item in payload.get('nameRows',[])
                        if isinstance(item,dict) and isinstance(item.get('text'),str)
                        and isinstance(item.get('cy'),(int,float))
                        and abs(item['cy']-row['cy'])<=max(5.0,typical*1.25)]
        row_name=clean_name(min(row_candidates,key=lambda r:abs(r['cy']-row['cy']))['text']) if row_candidates else ''
        primary_name=clean_name(fields['name'])
        crop_name=clean_name(cropped.get('name',''))
        def valid_name(value):
            return bool(re.fullmatch(r'[가-힣]{2,5}',value))
        # Per-row OCR gets priority when it reads a plausible Hangul name.
        # Do not silently substitute a name from a fixed list of patients.
        name=(row_name if valid_name(row_name) else
              crop_name if valid_name(crop_name) else primary_name)
        if not valid_name(name):
            name=max((row_name,crop_name,primary_name),key=len)

        def age_value(value):
            # SenseChart age format: 4y 6m or 1y 0m 27d.
            value=re.sub(r'\s+','',value).lower().translate(
                str.maketrans({'i':'1','l':'1','|':'1','ㅣ':'1','o':'0'}))
            full=re.fullmatch(r'(\d{1,2})y(\d{1,2})m(?:(\d{1,2})d?)?',value)
            if full and int(full[2])<12 and (not full[3] or int(full[3])<32):
                return f'{int(full[1])}y {int(full[2])}m'+(f' {int(full[3])}d' if full[3] else '')
            infant=re.fullmatch(r'(\d{1,2})m(?:(\d{1,2})d?)?',value)
            if infant and int(infant[1])<12 and (not infant[2] or int(infant[2])<32):
                return f'{int(infant[1])}m'+(f' {int(infant[2])}d' if infant[2] else '')
            return ''
        age_sources=[age_value(value) for value in (fields['age'],cropped.get('age',''),
                                                     row_reading.get('age',''))]
        valid_ages=[value for value in age_sources if value]
        if valid_ages:
            # A full years+months reading is more informative than a clipped
            # months-only fragment of the same row (e.g. "9m" vs "1y 9m").
            full_age_values=[value for value in valid_ages if re.match(r'^\d+y ',value)]
            if full_age_values:
                valid_ages=full_age_values
            from collections import Counter
            age_counts=Counter(valid_ages)
            # Require agreement when possible. On ties, prefer row-isolated OCR.
            max_count=max(age_counts.values())
            agreement=[value for value in valid_ages if age_counts[value]==max_count]
            row_age=age_value(row_reading.get('age',''))
            age=(row_age if row_age in agreement else
                 age_value(fields['age']) if age_value(fields['age']) in agreement else agreement[0])
        else:
            # Corrupted OCR like "19 염)" must not be presented as an age.
            age=''
        age_conflict=len(set(valid_ages))>1

        # Hospital day is a small numeric field; do not use admission-date digits.
        def clean_day(value):
            value=str(value).strip()
            match=re.fullmatch(r'0*([1-9]|[1-5]\d|60)',value)
            return str(int(match[1])) if match else ''
        row_day=clean_day(row_reading.get('day',''))
        crop_day=clean_day(cropped.get('day',''))
        original_day=clean_day(fields['day'])
        # If a cropped field is noisy, a clean row crop or full-pass number
        # can recover the value. Conflicting valid values are flagged.
        day=row_day or crop_day or original_day
        day_conflict=len({x for x in (row_day,crop_day,original_day) if x})>1
        # An explicit nonempty but invalid isolated reading with no row retry
        # remains uncertain even if full OCR happened to find a number.
        if cropped.get('day','').strip() and not crop_day and not row_day:
            day=''

        diagnosis_text=cropped.get('diagnosis','') or fields['diagnosis']
        combined=diagnosis_text+' '+fields['diagnosis']
        compact=re.sub(r'\s+','',combined)
        code_match=re.search(r'\(?\s*([A-Z]\d{2,4})\s*\)?',diagnosis_text,re.I)
        description=re.sub(r'^\s*\(?\s*[A-Z0-9]{3,5}\s*\)?\s*','',diagnosis_text,flags=re.I).strip()
        description=re.sub(r'^\s*[\d\)\(]+\s*','',description)
        if '상세불명' in compact and '폐렴' in compact:
            diagnosis='J189 상세불명의 폐렴'
        elif code_match:
            diagnosis=code_match.group(1).upper()+(' '+description if description else '')
        elif '폐렴' in compact:
            diagnosis='폐렴'
        else:
            diagnosis=description or diagnosis_text.strip(' ()')

        review=(not bool(room_text and valid_name(name) and age_value(age) and day)
                or age_conflict or day_conflict
                or (valid_name(primary_name) and valid_name(row_name) and primary_name!=row_name)
                or (bool(cropped.get('day','')) and fields['day'].strip() not in ('',day))
                or (diagnosis_text!=fields['diagnosis']))
        patients.append({'room':room_text,'name':name,'age':age,'day':day,
                        'diagnosis':diagnosis,'memo':'','review':review})
    return patients[:150]

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def log_message(self,*args): pass
    def end_headers(self):
        self.send_header("Cache-Control","no-store")
        super().end_headers()
    def json_response(self,data,status=200):
        raw=json.dumps(data,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
    def run_sensechart_screen_script(self,args,timeout=30):
        script=ROOT/'tools'/'sensechart-screen.ps1'
        return subprocess.run(
            ['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),*args],
            capture_output=True,text=True,encoding='utf-8',errors='replace',
            timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)
        )
    def do_GET(self):
        url=urlsplit(self.path)
        if url.path=='/api/browser-presence':
            if not same_origin(self):return self.send_error(403)
            self.send_response(200)
            self.send_header('Content-Type','text/event-stream; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Accel-Buffering','no')
            self.end_headers()
            try:
                while True:
                    # A server-driven stream avoids background-tab timer throttling.
                    self.wfile.write(b': connected\n\n')
                    self.wfile.flush()
                    BROWSER_PRESENCE.touch()
                    time.sleep(3)
            except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError,OSError):
                return
        if url.path=='/api/instance':
            if not same_origin(self):return self.send_error(403)
            return self.json_response({'folder':FOLDER_ID,'build':BUILD_ID})
        if url.path=='/api/sensechart-snapshot':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            temp_path=None
            try:
                with tempfile.NamedTemporaryFile(prefix='clinside-screen-',suffix='.png',delete=False) as tmp:
                    temp_path=tmp.name
                result=self.run_sensechart_screen_script(['-Mode','Snapshot','-OutputPath',temp_path],timeout=20)
                if result.returncode:raise RuntimeError((result.stderr or result.stdout or '화면 캡처에 실패했습니다.')[-1000:].strip())
                raw=Path(temp_path).read_bytes()
                if not 0<len(raw)<30000000:raise ValueError('화면 캡처 파일 크기를 확인해 주세요.')
                self.send_response(200);self.send_header('Content-Type','image/png');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw);return
            except subprocess.TimeoutExpired:return self.json_response({'error':'화면 캡처가 시간 초과되었습니다.'},504)
            except Exception as exc:return self.json_response({'error':str(exc)},500)
            finally:
                if temp_path:
                    try:os.unlink(temp_path)
                    except OSError:pass
        if url.path=='/api/chart-capture-area':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            if not AREA_FILE.is_file():return self.json_response({'area':None})
            try:
                area=json.loads(AREA_FILE.read_text(encoding='utf-8'))
                if not valid_capture_area(area):raise ValueError('invalid area')
                return self.json_response({'area':area})
            except Exception:return self.json_response({'error':'저장된 영역 파일을 읽을 수 없습니다.'},500)
        if url.path=='/api/shutdown-token':return self.json_response({'token':STOP_TOKEN})
        if url.path=='/api/sensechart-ocr':return self.send_error(405)
        if url.path=='/api/phrases':
            if not same_origin(self):return self.send_error(403)
            try:
                with PHRASES_LOCK: phrases=read_phrases()
                return self.json_response({'phrases':phrases})
            except (OSError,ValueError,json.JSONDecodeError):return self.json_response({'error':'문구 파일을 읽을 수 없습니다.'},500)
        if url.path=='/api/calculators':return self.json_response(calculator_pages())
        if url.path=='/api/patients':return self.json_response(STORE.patients(parse_qs(url.query).get('q',[''])[0]))
        if url.path.startswith('/api/patients/') and url.path.endswith('/visits'):
            return self.json_response(STORE.visits(url.path.split('/')[3]))
        if url.path=='/api/records':return self.json_response(STORE.visits())
        if url.path.startswith('/embedded/'):
            target=(ROOT/url.path.lstrip('/')).resolve()
            if not target.is_relative_to(ROOT/'embedded') or not target.is_file():
                return self.send_error(404)
            return super().do_GET()
        if url.path.startswith('/calculators/'):
            target=(CALCULATORS_DIR/unquote(url.path[len('/calculators/'):])).resolve()
            if not target.is_relative_to(CALCULATORS_DIR.resolve()) or not target.is_file():
                return self.send_error(404)
            return super().do_GET()
        if url.path not in ('/','/index.html','/app.js','/companion.js','/phrases.html','/inpatients.html','/style.css','/assets/chart.png','/assets/chart-a4.svg','/assets/clinside_logo.png'):
            return self.send_error(404)
        return super().do_GET()
    def do_POST(self):
        if self.path=='/api/inpatient-ocr':
            if not same_origin(self):return self.send_error(403)
            temp_path=None
            try:
                if self.headers.get('Content-Type','').split(';',1)[0].strip()!='image/png':
                    raise ValueError('PNG 이미지만 지원합니다.')
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<=8000000:raise ValueError('이미지는 8MB 이하여야 합니다.')
                raw=self.rfile.read(size)
                if raw[:4]!=bytes([137,80,78,71]):raise ValueError('PNG 형식이 아닙니다.')
                with tempfile.NamedTemporaryFile(prefix='clinside-inpatient-',suffix='.png',delete=False) as tmp:
                    tmp.write(raw);temp_path=tmp.name
                script=ROOT/'tools'/'inpatient-ocr.ps1'
                process=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),'-ImagePath',temp_path],
                    capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=45,
                    creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                if process.returncode:raise RuntimeError((process.stderr or process.stdout or 'OCR에 실패했습니다.')[-800:].strip())
                payload=json.loads(process.stdout.strip())
                return self.json_response({'patients':parse_inpatient_words(payload)})
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except subprocess.TimeoutExpired:return self.json_response({'error':'OCR 처리 시간이 초과되었습니다.'},504)
            except Exception as exc:return self.json_response({'error':str(exc)},500)
            finally:
                if temp_path:
                    try:os.unlink(temp_path)
                    except OSError:pass

        if self.path=='/api/phrases':
            if not same_origin(self):return self.send_error(403)
            try:
                if self.headers.get('Content-Type','').split(';',1)[0].strip()!='application/json':
                    raise ValueError('JSON 요청만 사용할 수 있습니다.')
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<=1500000:raise ValueError('저장할 문구의 크기가 올바르지 않습니다.')
                payload=json.loads(self.rfile.read(size))
                if not isinstance(payload,dict):raise ValueError('요청 형식이 올바르지 않습니다.')
                phrases=validate_phrases(payload.get('phrases'))
                with PHRASES_LOCK:
                    with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=DATA,prefix='.phrases-',suffix='.tmp',delete=False) as f:
                        temp_path=Path(f.name)
                        json.dump(phrases,f,ensure_ascii=False,indent=2)
                        f.flush();os.fsync(f.fileno())
                    try:temp_path.replace(PHRASES_FILE)
                    finally:temp_path.unlink(missing_ok=True)
                return self.json_response({'phrases':phrases})
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except OSError:return self.json_response({'error':'문구 저장에 실패했습니다. data 폴더의 쓰기 권한을 확인하세요.'},500)
        if self.path=='/api/phrases':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<=1048576:raise ValueError('문구 데이터는 1MB 이내여야 합니다.')
                payload=json.loads(self.rfile.read(size))
                phrases=payload.get('phrases') if isinstance(payload,dict) else None
                if not isinstance(phrases,list) or len(phrases)>1000:raise ValueError('문구는 최대 1000개까지 저장할 수 있습니다.')
                ids=set()
                for item in phrases:
                    if not isinstance(item,dict) or set(item)!={'id','category','title','content'}:raise ValueError('문구 형식이 올바르지 않습니다.')
                    if not isinstance(item['id'],str) or not 1<=len(item['id'])<=100 or item['id'] in ids:raise ValueError('문구 ID가 올바르지 않습니다.')
                    ids.add(item['id'])
                    if item['category'] not in ('진료 문구','환자 문자'):raise ValueError('문구 분류가 올바르지 않습니다.')
                    if not isinstance(item['title'],str) or not 1<=len(item['title'].strip())<=120:raise ValueError('제목은 1~120자여야 합니다.')
                    if not isinstance(item['content'],str) or not 1<=len(item['content'].strip())<=10000:raise ValueError('본문은 1~10000자여야 합니다.')
                target=DATA/'phrases.json'
                temp=DATA/'phrases.json.tmp'
                temp.write_text(json.dumps(phrases,ensure_ascii=False,indent=2),encoding='utf-8')
                temp.replace(target)
                return self.json_response({'ok':True,'count':len(phrases)})
            except (ValueError,TypeError,KeyError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except OSError:return self.json_response({'error':'문구를 저장하지 못했습니다. 저장 폴더 권한을 확인해주세요.'},500)
        if self.path=='/api/chart-capture-area':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<4096:raise ValueError('영역 정보 크기가 올바르지 않습니다.')
                area=json.loads(self.rfile.read(size))
                if not valid_capture_area(area):raise ValueError('영역 좌표가 올바르지 않습니다.')
                temp_file=AREA_FILE.with_suffix('.json.tmp')
                temp_file.write_text(json.dumps(area,ensure_ascii=False),encoding='utf-8')
                temp_file.replace(AREA_FILE)
                return self.json_response({'ok':True,'area':area})
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except OSError:return self.json_response({'error':'영역 파일 저장에 실패했습니다. ClinSide 폴더의 쓰기 권한을 확인해주세요.'},500)
        if self.path=='/api/sensechart-screen-ocr':
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            temp_path=None
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<10000:raise ValueError('화면 영역 정보를 확인해 주세요.')
                payload=json.loads(self.rfile.read(size))
                coords=[]
                for key in ('x','y','width','height'):
                    value=payload.get(key)
                    if type(value) is not int:raise ValueError('화면 영역 좌표가 올바르지 않습니다.')
                    coords.append(value)
                with tempfile.NamedTemporaryFile(prefix='clinside-ocr-screen-',suffix='.png',delete=False) as tmp:
                    temp_path=tmp.name
                x,y,width,height=coords
                result=self.run_sensechart_screen_script(['-Mode','ReadArea','-OutputPath',temp_path,'-X',str(x),'-Y',str(y),'-Width',str(width),'-Height',str(height)],timeout=30)
                if result.returncode:raise RuntimeError((result.stderr or result.stdout or '화면 캡처/OCR에 실패했습니다.')[-1000:].strip())
                return self.json_response(json.loads(result.stdout.strip()))
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except subprocess.TimeoutExpired:return self.json_response({'error':'화면 읽기가 시간 초과되었습니다.'},504)
            except Exception as exc:return self.json_response({'error':str(exc)},500)
            finally:
                if temp_path:
                    try:os.unlink(temp_path)
                    except OSError:pass
        if self.path=='/api/sensechart-ocr':
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            temp_path=None
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<5000000:raise ValueError('캡처 이미지 크기를 확인해주세요.')
                payload=json.loads(self.rfile.read(size))
                image=payload.get('image','')
                match=re.fullmatch(r'data:image/png;base64,([A-Za-z0-9+/=]+)',image)
                if not match:raise ValueError('PNG 캡처 이미지만 처리할 수 있습니다.')
                raw=base64.b64decode(match.group(1),validate=True)
                if not 0<len(raw)<4000000:raise ValueError('캡처 이미지 크기가 너무 큽니다.')
                with tempfile.NamedTemporaryFile(prefix='clinside-ocr-',suffix='.png',delete=False) as tmp:
                    tmp.write(raw);temp_path=tmp.name
                script=ROOT/'tools'/'sensechart-ocr.ps1'
                result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),'-ImagePath',temp_path],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                if result.returncode:raise RuntimeError((result.stderr or result.stdout or 'Windows OCR 실행에 실패했습니다.')[-1000:].strip())
                return self.json_response(json.loads(result.stdout.strip()))
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except subprocess.TimeoutExpired:return self.json_response({'error':'화면 읽기가 시간 초과되었습니다. 다시 시도해주세요.'},504)
            except Exception as exc:return self.json_response({'error':str(exc)},500)
            finally:
                if temp_path:
                    try:os.unlink(temp_path)
                    except OSError:pass
        if self.path=='/api/shutdown':
            if self.headers.get('X-ClinSide-Token')!=STOP_TOKEN:return self.send_error(403)
            self.json_response({'ok':True})
            threading.Thread(target=server.shutdown,daemon=True).start()
            return
        if self.path not in ('/api/records','/api/followup-page'):return self.send_error(404)
        origin=self.headers.get('Origin')
        if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
        try:
            size=int(self.headers.get('Content-Length',0))
            if not 0<size<1000000:raise ValueError('기록 크기를 확인해주세요.')
            value=json.loads(self.rfile.read(size));self.json_response(STORE.save_followup_page(value) if self.path=='/api/followup-page' else STORE.save(value))
        except (ValueError,TypeError,AttributeError) as exc:self.json_response({'error':str(exc)},400)
        except Exception:self.json_response({'error':'저장에 실패했습니다. 실행 창과 저장 폴더를 확인해주세요.'},500)
if __name__=='__main__':
    STORE=Store(DATA/'clinic.sqlite3')
    migration_errors=STORE.migrate(RECORDS)
    if migration_errors:print('일부 이전 기록을 가져오지 못했습니다. 기존 JSON 파일은 보존됩니다. 파일 수:',len(migration_errors),flush=True)
    for port in range(8765,8786):
        try: server=ThreadingHTTPServer(('127.0.0.1',port),Handler);break
        except OSError:continue
    else:raise SystemExit('사용 가능한 포트가 없습니다.')
    url=f'http://127.0.0.1:{port}'
    CONTROL_FILE.write_text(json.dumps({'pid':os.getpid(),'port':port,'token':STOP_TOKEN}),encoding='utf-8')
    print(f'ClinSide: {url}',flush=True)
    if os.environ.get('NO_BROWSER')!='1' and os.environ.get('CLINSIDE_NO_BROWSER')!='1':threading.Timer(.5,lambda:webbrowser.open(url)).start()
    threading.Thread(target=monitor_browser_presence,args=(server,),daemon=True).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        server.server_close()
        CONTROL_FILE.unlink(missing_ok=True)
