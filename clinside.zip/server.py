#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, webbrowser, threading, hashlib
from urllib.parse import urlsplit,parse_qs,quote,unquote
import secrets
import re, html, base64, tempfile, subprocess
from storage import Store
ROOT=Path(__file__).resolve().parent
APP_FILES = ('server.py', 'phrases.html', 'companion.js')
def app_build_id(root):
    digest = hashlib.sha256()
    for name in APP_FILES:
        digest.update(name.encode('utf-8'))
        digest.update((root / name).read_bytes())
    return digest.hexdigest()
FOLDER_ID = hashlib.sha256(str(ROOT).casefold().encode('utf-8')).hexdigest()
BUILD_ID = app_build_id(ROOT)
RECORDS=ROOT/'records'
DATA=ROOT/'data'
DATA.mkdir(exist_ok=True)
AREA_FILE=DATA/'chart-capture-area.json'
LEGACY_AREA_FILE=ROOT/'chart-capture-area.json'
if LEGACY_AREA_FILE.is_file() and not AREA_FILE.exists():
    try:
        legacy_area=json.loads(LEGACY_AREA_FILE.read_text(encoding='utf-8'))
        if (isinstance(legacy_area,dict) and all(type(legacy_area.get(k)) is int for k in ('x','y','width','height'))
                and legacy_area['x']>=0 and legacy_area['y']>=0 and legacy_area['width']>0 and legacy_area['height']>0):
            AREA_FILE.write_text(json.dumps(legacy_area,ensure_ascii=False),encoding='utf-8')
    except (OSError,ValueError,TypeError,json.JSONDecodeError):
        pass
CALCULATORS_DIR=ROOT/'calculators'
CALCULATORS_DIR.mkdir(exist_ok=True)
CONTROL_FILE=DATA/'clinside-server.json'
PHRASES_FILE=DATA/'phrases.json'
PHRASES_LOCK=threading.Lock()
def normalize_phrase_category(category):
    return {'진료 문구':'진료','환자 문자':'메시지'}.get(category,category)

def read_phrases():
    if not PHRASES_FILE.exists():return []
    value=json.loads(PHRASES_FILE.read_text(encoding='utf-8'))
    if not isinstance(value,list):raise ValueError('문구 파일 형식이 올바르지 않습니다.')
    return [{**row,'category':normalize_phrase_category(row.get('category'))} if isinstance(row,dict) else row for row in value]

def validate_phrases(value):
    if not isinstance(value,list) or len(value)>2000:raise ValueError('문구는 최대 2,000개까지 저장할 수 있습니다.')
    result=[];ids=set()
    for row in value:
        if not isinstance(row,dict):raise ValueError('문구 형식이 올바르지 않습니다.')
        pid=row.get('id');category=row.get('category');title=row.get('title');content=row.get('content')
        if not isinstance(pid,str) or not 1<=len(pid)<=100 or pid in ids:raise ValueError('문구 ID가 올바르지 않습니다.')
        category=normalize_phrase_category(category)
        if not isinstance(category,str) or not category.strip() or len(category.strip())>40:raise ValueError('문구 분류는 40자 이내로 입력해주세요.')
        category=category.strip()
        if not isinstance(title,str) or not title.strip() or len(title)>120:raise ValueError('문구 제목을 확인해주세요.')
        if not isinstance(content,str) or not content.strip() or len(content)>10000:raise ValueError('문구 내용을 확인해주세요.')
        ids.add(pid);result.append({'id':pid,'category':category,'title':title.strip(),'content':content})
    return result

def same_origin(handler):
    origin=handler.headers.get('Origin')
    host=handler.headers.get('Host')
    site=handler.headers.get('Sec-Fetch-Site')
    return (not origin or origin==f'http://{host}') and (not site or site in ('same-origin','none'))

STOP_TOKEN=secrets.token_urlsafe(32)

def valid_capture_area(value):
    return (isinstance(value,dict)
            and all(type(value.get(key)) is int for key in ('x','y','width','height'))
            and value['x']>=0 and value['y']>=0 and value['width']>0 and value['height']>0)

def calculator_pages():
    pages=[]
    for path in sorted(CALCULATORS_DIR.rglob('*')):
        if not path.is_file() or path.suffix.lower() not in ('.html','.htm'):continue
        if any(part.startswith('.') for part in path.relative_to(CALCULATORS_DIR).parts):continue
        source=path.read_text(encoding='utf-8',errors='replace')
        match=re.search(r'<title\b[^>]*>(.*?)</title\s*>',source,re.IGNORECASE|re.DOTALL)
        title=html.unescape(re.sub(r'<[^>]+>','',match.group(1))).strip() if match else path.stem
        pages.append({'title':title or path.stem,'path':path.relative_to(CALCULATORS_DIR).as_posix(),'url':'/calculators/'+quote(path.relative_to(CALCULATORS_DIR).as_posix())})
    return pages

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def log_message(self,*args): pass
    def end_headers(self):
        self.send_header("Cache-Control","no-store")
        super().end_headers()
    def json_response(self,data,status=200):
        raw=json.dumps(data,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
    def run_sensechart_screen_script(self,args,timeout=30):
        script=ROOT/'tools'/'sensechart-screen.ps1'
        return subprocess.run(
            ['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),*args],
            capture_output=True,text=True,encoding='utf-8',errors='replace',
            timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)
        )
    def do_GET(self):
        url=urlsplit(self.path)
        if url.path=='/api/instance':
            if not same_origin(self):return self.send_error(403)
            return self.json_response({'folder':FOLDER_ID,'build':BUILD_ID})
        if url.path=='/api/sensechart-snapshot':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            temp_path=None
            try:
                with tempfile.NamedTemporaryFile(prefix='clinside-screen-',suffix='.png',delete=False) as tmp:
                    temp_path=tmp.name
                result=self.run_sensechart_screen_script(['-Mode','Snapshot','-OutputPath',temp_path],timeout=20)
                if result.returncode:raise RuntimeError((result.stderr or result.stdout or '화면 캡처에 실패했습니다.')[-1000:].strip())
                raw=Path(temp_path).read_bytes()
                if not 0<len(raw)<30000000:raise ValueError('화면 캡처 파일 크기를 확인해 주세요.')
                self.send_response(200);self.send_header('Content-Type','image/png');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw);return
            except subprocess.TimeoutExpired:return self.json_response({'error':'화면 캡처가 시간 초과되었습니다.'},504)
            except Exception as exc:return self.json_response({'error':str(exc)},500)
            finally:
                if temp_path:
                    try:os.unlink(temp_path)
                    except OSError:pass
        if url.path=='/api/chart-capture-area':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            if not AREA_FILE.is_file():return self.json_response({'area':None})
            try:
                area=json.loads(AREA_FILE.read_text(encoding='utf-8'))
                if not valid_capture_area(area):raise ValueError('invalid area')
                return self.json_response({'area':area})
            except Exception:return self.json_response({'error':'저장된 영역 파일을 읽을 수 없습니다.'},500)
        if url.path=='/api/shutdown-token':return self.json_response({'token':STOP_TOKEN})
        if url.path=='/api/sensechart-ocr':return self.send_error(405)
        if url.path=='/api/phrases':
            if not same_origin(self):return self.send_error(403)
            try:
                with PHRASES_LOCK: phrases=read_phrases()
                return self.json_response({'phrases':phrases})
            except (OSError,ValueError,json.JSONDecodeError):return self.json_response({'error':'문구 파일을 읽을 수 없습니다.'},500)
        if url.path=='/api/calculators':return self.json_response(calculator_pages())
        if url.path=='/api/patients':return self.json_response(STORE.patients(parse_qs(url.query).get('q',[''])[0]))
        if url.path.startswith('/api/patients/') and url.path.endswith('/visits'):
            return self.json_response(STORE.visits(url.path.split('/')[3]))
        if url.path=='/api/records':return self.json_response(STORE.visits())
        if url.path.startswith('/embedded/'):
            target=(ROOT/url.path.lstrip('/')).resolve()
            if not target.is_relative_to(ROOT/'embedded') or not target.is_file():
                return self.send_error(404)
            return super().do_GET()
        if url.path.startswith('/calculators/'):
            target=(CALCULATORS_DIR/unquote(url.path[len('/calculators/'):])).resolve()
            if not target.is_relative_to(CALCULATORS_DIR.resolve()) or not target.is_file():
                return self.send_error(404)
            return super().do_GET()
        if url.path not in ('/','/index.html','/app.js','/companion.js','/phrases.html','/style.css','/assets/chart.png','/assets/chart-a4.svg','/assets/clinside_logo.png'):
            return self.send_error(404)
        return super().do_GET()
    def do_POST(self):
        if self.path=='/api/phrases':
            if not same_origin(self):return self.send_error(403)
            try:
                if self.headers.get('Content-Type','').split(';',1)[0].strip()!='application/json':
                    raise ValueError('JSON 요청만 사용할 수 있습니다.')
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<=1500000:raise ValueError('저장할 문구의 크기가 올바르지 않습니다.')
                payload=json.loads(self.rfile.read(size))
                if not isinstance(payload,dict):raise ValueError('요청 형식이 올바르지 않습니다.')
                phrases=validate_phrases(payload.get('phrases'))
                with PHRASES_LOCK:
                    with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=DATA,prefix='.phrases-',suffix='.tmp',delete=False) as f:
                        temp_path=Path(f.name)
                        json.dump(phrases,f,ensure_ascii=False,indent=2)
                        f.flush();os.fsync(f.fileno())
                    try:temp_path.replace(PHRASES_FILE)
                    finally:temp_path.unlink(missing_ok=True)
                return self.json_response({'phrases':phrases})
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except OSError:return self.json_response({'error':'문구 저장에 실패했습니다. data 폴더의 쓰기 권한을 확인하세요.'},500)
        if self.path=='/api/phrases':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<=1048576:raise ValueError('문구 데이터는 1MB 이내여야 합니다.')
                payload=json.loads(self.rfile.read(size))
                phrases=payload.get('phrases') if isinstance(payload,dict) else None
                if not isinstance(phrases,list) or len(phrases)>1000:raise ValueError('문구는 최대 1000개까지 저장할 수 있습니다.')
                ids=set()
                for item in phrases:
                    if not isinstance(item,dict) or set(item)!={'id','category','title','content'}:raise ValueError('문구 형식이 올바르지 않습니다.')
                    if not isinstance(item['id'],str) or not 1<=len(item['id'])<=100 or item['id'] in ids:raise ValueError('문구 ID가 올바르지 않습니다.')
                    ids.add(item['id'])
                    if item['category'] not in ('진료 문구','환자 문자'):raise ValueError('문구 분류가 올바르지 않습니다.')
                    if not isinstance(item['title'],str) or not 1<=len(item['title'].strip())<=120:raise ValueError('제목은 1~120자여야 합니다.')
                    if not isinstance(item['content'],str) or not 1<=len(item['content'].strip())<=10000:raise ValueError('본문은 1~10000자여야 합니다.')
                target=DATA/'phrases.json'
                temp=DATA/'phrases.json.tmp'
                temp.write_text(json.dumps(phrases,ensure_ascii=False,indent=2),encoding='utf-8')
                temp.replace(target)
                return self.json_response({'ok':True,'count':len(phrases)})
            except (ValueError,TypeError,KeyError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except OSError:return self.json_response({'error':'문구를 저장하지 못했습니다. 저장 폴더 권한을 확인해주세요.'},500)
        if self.path=='/api/chart-capture-area':
            origin=self.headers.get('Origin')
            fetch_site=self.headers.get('Sec-Fetch-Site')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            if fetch_site and fetch_site not in ('same-origin','none'):return self.send_error(403)
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<4096:raise ValueError('영역 정보 크기가 올바르지 않습니다.')
                area=json.loads(self.rfile.read(size))
                if not valid_capture_area(area):raise ValueError('영역 좌표가 올바르지 않습니다.')
                temp_file=AREA_FILE.with_suffix('.json.tmp')
                temp_file.write_text(json.dumps(area,ensure_ascii=False),encoding='utf-8')
                temp_file.replace(AREA_FILE)
                return self.json_response({'ok':True,'area':area})
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except OSError:return self.json_response({'error':'영역 파일 저장에 실패했습니다. ClinSide 폴더의 쓰기 권한을 확인해주세요.'},500)
        if self.path=='/api/sensechart-screen-ocr':
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            temp_path=None
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<10000:raise ValueError('화면 영역 정보를 확인해 주세요.')
                payload=json.loads(self.rfile.read(size))
                coords=[]
                for key in ('x','y','width','height'):
                    value=payload.get(key)
                    if type(value) is not int:raise ValueError('화면 영역 좌표가 올바르지 않습니다.')
                    coords.append(value)
                with tempfile.NamedTemporaryFile(prefix='clinside-ocr-screen-',suffix='.png',delete=False) as tmp:
                    temp_path=tmp.name
                x,y,width,height=coords
                result=self.run_sensechart_screen_script(['-Mode','ReadArea','-OutputPath',temp_path,'-X',str(x),'-Y',str(y),'-Width',str(width),'-Height',str(height)],timeout=30)
                if result.returncode:raise RuntimeError((result.stderr or result.stdout or '화면 캡처/OCR에 실패했습니다.')[-1000:].strip())
                return self.json_response(json.loads(result.stdout.strip()))
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except subprocess.TimeoutExpired:return self.json_response({'error':'화면 읽기가 시간 초과되었습니다.'},504)
            except Exception as exc:return self.json_response({'error':str(exc)},500)
            finally:
                if temp_path:
                    try:os.unlink(temp_path)
                    except OSError:pass
        if self.path=='/api/sensechart-ocr':
            origin=self.headers.get('Origin')
            if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
            temp_path=None
            try:
                size=int(self.headers.get('Content-Length',0))
                if not 0<size<5000000:raise ValueError('캡처 이미지 크기를 확인해주세요.')
                payload=json.loads(self.rfile.read(size))
                image=payload.get('image','')
                match=re.fullmatch(r'data:image/png;base64,([A-Za-z0-9+/=]+)',image)
                if not match:raise ValueError('PNG 캡처 이미지만 처리할 수 있습니다.')
                raw=base64.b64decode(match.group(1),validate=True)
                if not 0<len(raw)<4000000:raise ValueError('캡처 이미지 크기가 너무 큽니다.')
                with tempfile.NamedTemporaryFile(prefix='clinside-ocr-',suffix='.png',delete=False) as tmp:
                    tmp.write(raw);temp_path=tmp.name
                script=ROOT/'tools'/'sensechart-ocr.ps1'
                result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),'-ImagePath',temp_path],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                if result.returncode:raise RuntimeError((result.stderr or result.stdout or 'Windows OCR 실행에 실패했습니다.')[-1000:].strip())
                return self.json_response(json.loads(result.stdout.strip()))
            except (ValueError,TypeError,json.JSONDecodeError) as exc:return self.json_response({'error':str(exc)},400)
            except subprocess.TimeoutExpired:return self.json_response({'error':'화면 읽기가 시간 초과되었습니다. 다시 시도해주세요.'},504)
            except Exception as exc:return self.json_response({'error':str(exc)},500)
            finally:
                if temp_path:
                    try:os.unlink(temp_path)
                    except OSError:pass
        if self.path=='/api/shutdown':
            if self.headers.get('X-ClinSide-Token')!=STOP_TOKEN:return self.send_error(403)
            self.json_response({'ok':True})
            threading.Thread(target=server.shutdown,daemon=True).start()
            return
        if self.path not in ('/api/records','/api/followup-page'):return self.send_error(404)
        origin=self.headers.get('Origin')
        if origin and origin!=f'http://{self.headers.get("Host")}':return self.send_error(403)
        try:
            size=int(self.headers.get('Content-Length',0))
            if not 0<size<1000000:raise ValueError('기록 크기를 확인해주세요.')
            value=json.loads(self.rfile.read(size));self.json_response(STORE.save_followup_page(value) if self.path=='/api/followup-page' else STORE.save(value))
        except (ValueError,TypeError,AttributeError) as exc:self.json_response({'error':str(exc)},400)
        except Exception:self.json_response({'error':'저장에 실패했습니다. 실행 창과 저장 폴더를 확인해주세요.'},500)
if __name__=='__main__':
    STORE=Store(DATA/'clinic.sqlite3')
    migration_errors=STORE.migrate(RECORDS)
    if migration_errors:print('일부 이전 기록을 가져오지 못했습니다. 기존 JSON 파일은 보존됩니다. 파일 수:',len(migration_errors),flush=True)
    for port in range(8765,8786):
        try: server=ThreadingHTTPServer(('127.0.0.1',port),Handler);break
        except OSError:continue
    else:raise SystemExit('사용 가능한 포트가 없습니다.')
    url=f'http://127.0.0.1:{port}'
    CONTROL_FILE.write_text(json.dumps({'pid':os.getpid(),'port':port,'token':STOP_TOKEN}),encoding='utf-8')
    print(f'ClinSide: {url}',flush=True)
    if os.environ.get('NO_BROWSER')!='1' and os.environ.get('CLINSIDE_NO_BROWSER')!='1':threading.Timer(.5,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        server.server_close()
        CONTROL_FILE.unlink(missing_ok=True)
