param([Parameter(Mandatory=$true)][string]$ImagePath)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Drawing
$null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Storage.FileAccessMode,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrEngine,Windows.Media.Ocr,ContentType=WindowsRuntime]
$null=[Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
function Await-WinRT($op,[Type]$type) {
 $method=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
 if(-not $method){throw 'Windows OCR async support unavailable.'}
 $task=$method.MakeGenericMethod($type).Invoke($null,@($op))
 return $task.GetAwaiter().GetResult()
}
[Console]::OutputEncoding=[Text.Encoding]::UTF8
$language=[Windows.Globalization.Language]::new('ko-KR')
$engine=[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
if(-not $engine){throw 'Windows 한국어 OCR 언어팩이 필요합니다.'}
$source=[Drawing.Bitmap]::FromFile($ImagePath)
$scaledPath=$null
try {
 $scale=[Math]::Max(1.0,[Math]::Min(4.0,[Math]::Min(2400/$source.Width,1400/$source.Height)))
 $target=$ImagePath
 if($scale -gt 1.01){
  $scaledPath=Join-Path $env:TEMP ('clinside-inpatients-'+[guid]::NewGuid().ToString('N')+'.png')
  $resized=[Drawing.Bitmap]::new([int][Math]::Ceiling($source.Width*$scale),[int][Math]::Ceiling($source.Height*$scale))
  try {
   $g=[Drawing.Graphics]::FromImage($resized)
   try {$g.Clear([Drawing.Color]::White);$g.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic;$g.DrawImage($source,0,0,$resized.Width,$resized.Height)}finally{$g.Dispose()}
   $resized.Save($scaledPath,[Drawing.Imaging.ImageFormat]::Png)
  }finally{$resized.Dispose()}
  $target=$scaledPath
 }
 $file=Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($target)) ([Windows.Storage.StorageFile])
 $stream=Await-WinRT ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
 try{
  $decoder=Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bitmap=Await-WinRT ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $result=Await-WinRT ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
  $words=@(foreach($line in $result.Lines){foreach($word in $line.Words){$b=$word.BoundingRect;@{text=$word.Text;x=($b.X/$scale);y=($b.Y/$scale);w=($b.Width/$scale);h=($b.Height/$scale)}}})
  # Recognize individual columns as well. Small EMR rows read poorly as one wide line,
  # particularly Korean names, English age markers and the J18.9 diagnosis code.
  $columnWords=@{}
  $columnRanges=@(
   @{key='room';left=0.155;right=0.230},
   @{key='name';left=0.275;right=0.418},
   @{key='age';left=0.410;right=0.515},
   @{key='day';left=0.710;right=0.754},
   @{key='diagnosis';left=0.765;right=1.0}
  )
  $scaled=[Drawing.Bitmap]::FromFile($target)
  try {
   foreach($column in $columnRanges){
    $start=[int][Math]::Floor($scaled.Width*$column.left)
    $end=[int][Math]::Ceiling($scaled.Width*$column.right)
    $cropWidth=[Math]::Max(1,$end-$start)
    # Enlarged, padded crops improve short numeric/text snippets without changing the screenshot.
    $padding=28
    $outputScale=2
    $cropBitmap=[Drawing.Bitmap]::new([int]($cropWidth*$outputScale+2*$padding),[int]($scaled.Height*$outputScale+2*$padding))
    $cropPath=Join-Path $env:TEMP ('clinside-ocr-col-'+[guid]::NewGuid().ToString('N')+'.png')
    try {
     $g=[Drawing.Graphics]::FromImage($cropBitmap)
     try {
      $g.Clear([Drawing.Color]::White)
      $g.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
      $rect=[Drawing.Rectangle]::new([int]$start,0,[int]$cropWidth,[int]$scaled.Height)
      $destRect=[Drawing.Rectangle]::new([int]$padding,[int]$padding,[int]($cropWidth*$outputScale),[int]($scaled.Height*$outputScale))
      $g.DrawImage($scaled,$destRect,$rect,[Drawing.GraphicsUnit]::Pixel)
     }finally{$g.Dispose()}
     $cropBitmap.Save($cropPath,[Drawing.Imaging.ImageFormat]::Png)
    }finally{$cropBitmap.Dispose()}
    try {
     $cropFile=Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($cropPath)) ([Windows.Storage.StorageFile])
     $cropStream=Await-WinRT ($cropFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
     try {
      $cropDecoder=Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($cropStream)) ([Windows.Graphics.Imaging.BitmapDecoder])
      $cropSoftware=Await-WinRT ($cropDecoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
      $cropResult=Await-WinRT ($engine.RecognizeAsync($cropSoftware)) ([Windows.Media.Ocr.OcrResult])
      $columnWords[$column.key]=@(foreach($line in $cropResult.Lines){foreach($word in $line.Words){
       $b=$word.BoundingRect
       @{text=$word.Text;x=(($start+($b.X-$padding)/$outputScale)/$scale);y=(($b.Y-$padding)/$outputScale/$scale);w=($b.Width/$outputScale/$scale);h=($b.Height/$outputScale/$scale)}
      }})
     }finally{if($cropStream){$cropStream.Dispose()}}
    }finally{Remove-Item -LiteralPath $cropPath -Force -ErrorAction SilentlyContinue}
   }
  # Retry short fields per patient row to avoid the header, grid lines and
  # neighboring columns being interpreted as part of a value.
  $rowReadings=@()
  $centers=@($words | Where-Object {
    ($_.x -ge $source.Width*0.08) -and ($_.x -lt $source.Width*0.28) -and
    ($_.y -gt $source.Height*0.16)
  } | ForEach-Object { $_.y+$_.h/2 } | Sort-Object)
  $rowCenters=New-Object 'System.Collections.Generic.List[double]'
  foreach($cy in $centers){
    $found=$false
    for($i=0;$i -lt $rowCenters.Count;$i++){
      if([Math]::Abs($rowCenters[$i]-$cy) -lt 6){$found=$true;break}
    }
    if(-not $found){$rowCenters.Add([double]$cy)}
  }
  $rowRegions=@(
    @{key='name';left=0.275;right=0.425},
    @{key='age';left=0.410;right=0.515},
    @{key='day';left=0.710;right=0.754}
  )
  foreach($cy in $rowCenters){
    if($rowReadings.Count -ge 150){break}
    $readings=@{cy=[double]$cy}
    foreach($region in $rowRegions){
      $x=[int][Math]::Floor($scaled.Width*$region.left)
      $right=[int][Math]::Ceiling($scaled.Width*$region.right)
      $rowTop=[int][Math]::Max(0,[Math]::Floor(($cy-6)*$scale))
      $rowBottom=[int][Math]::Min($scaled.Height,[Math]::Ceiling(($cy+7)*$scale))
      $rw=[int]($right-$x);$rh=[int]($rowBottom-$rowTop)
      if($rw -lt 4 -or $rh -lt 4){continue}
      $pad=30;$factor=3
      $one=[Drawing.Bitmap]::new([int]($rw*$factor+2*$pad),[int]($rh*$factor+2*$pad))
      $path=Join-Path $env:TEMP ('clinside-ocr-row-'+[guid]::NewGuid().ToString('N')+'.png')
      try{
        $graphics=[Drawing.Graphics]::FromImage($one)
        try{
          $graphics.Clear([Drawing.Color]::White)
          $graphics.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
          $graphics.DrawImage($scaled,
            [Drawing.Rectangle]::new([int]$pad,[int]$pad,[int]($rw*$factor),[int]($rh*$factor)),
            [Drawing.Rectangle]::new([int]$x,[int]$rowTop,[int]$rw,[int]$rh),
            [Drawing.GraphicsUnit]::Pixel)
        }finally{$graphics.Dispose()}
        $one.Save($path,[Drawing.Imaging.ImageFormat]::Png)
      }finally{$one.Dispose()}
      try{
        $rowFile=Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
        $rowStream=Await-WinRT ($rowFile.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        try{
          $rowDecoder=Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($rowStream)) ([Windows.Graphics.Imaging.BitmapDecoder])
          $rowBitmap=Await-WinRT ($rowDecoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
          $recognized=Await-WinRT ($engine.RecognizeAsync($rowBitmap)) ([Windows.Media.Ocr.OcrResult])
          $value=(($recognized.Lines | ForEach-Object { $_.Text }) -join ' ').Trim()
          if($value){$readings[$region.key]=$value}
        }finally{if($rowStream){$rowStream.Dispose()}}
      }finally{Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue}
    }
    $rowReadings+=,$readings
  }
  # Older parser clients can still consume nameRows.
  $nameRows=@(foreach($item in $rowReadings){if($item.name){@{cy=$item.cy;text=$item.name}}})
  }finally{$scaled.Dispose()}
  [Console]::WriteLine((@{width=$source.Width;height=$source.Height;words=$words;columns=$columnWords;nameRows=$nameRows;rowReadings=$rowReadings}|ConvertTo-Json -Compress -Depth 7))
 }finally{if($stream){$stream.Dispose()}}
}finally{$source.Dispose();if($scaledPath){Remove-Item -LiteralPath $scaledPath -Force -ErrorAction SilentlyContinue}}
