param([Parameter(Mandatory=$true)][string]$ImagePath)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Drawing
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapPixelFormat, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapAlphaMode, Windows.Graphics.Imaging, ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Media.Ocr, ContentType=WindowsRuntime]
function Await-WinRT($Operation, [Type]$ResultType) {
    $method = [System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } |
        Select-Object -First 1
    if (-not $method) { throw 'Windows OCR async support is unavailable.' }
    $task = $method.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
    $task.GetAwaiter().GetResult()
}
$file = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($ImagePath)) ([Windows.Storage.StorageFile])
$stream = Await-WinRT ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await-WinRT ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
# Screen captures often contain small EMR text; enlarge it before OCR.
$ocrPath = $ImagePath
$sourceBitmap = [System.Drawing.Bitmap]::FromFile($ImagePath)
$scale = [Math]::Min(4.0, [Math]::Max(1.0, 48.0 / [Math]::Max(1, $sourceBitmap.Height)))
if ($scale -gt 1.0) {
    $scaledPath = Join-Path $env:TEMP ([guid]::NewGuid().ToString() + '.png')
    $scaledBitmap = New-Object System.Drawing.Bitmap([int][Math]::Ceiling($sourceBitmap.Width * $scale), [int][Math]::Ceiling($sourceBitmap.Height * $scale))
    $graphics = [System.Drawing.Graphics]::FromImage($scaledBitmap)
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $graphics.DrawImage($sourceBitmap, 0, 0, $scaledBitmap.Width, $scaledBitmap.Height)
    $scaledBitmap.Save($scaledPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $graphics.Dispose()
    $scaledBitmap.Dispose()
    $ocrPath = $scaledPath
}
$sourceBitmap.Dispose()
$file = Await-WinRT ([Windows.Storage.StorageFile]::GetFileFromPathAsync($ocrPath)) ([Windows.Storage.StorageFile])
$stream = Await-WinRT ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await-WinRT ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await-WinRT ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if (-not $engine) { throw 'Korean OCR language support is not installed in Windows.' }
$result = Await-WinRT ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$text = ($result.Lines | ForEach-Object { $_.Text }) -join ' '
$labelSex = $null
if ($text -match '\uC5EC\uC544|\uC5EC\uC131|\uC5EC') { $labelSex = 2 }
elseif ($text -match '\uB0A8\uC544|\uB0A8\uC131|\uB0A8') { $labelSex = 1 }
$sex = $null
$sexMarkerSeen = $false
$dob = $null
# Read the date and, when present, only the first digit after the RRN hyphen.
# Also support a date field followed by a separate RRN field separated by whitespace.
$patterns = @(
    '(?<!\d)(\d{2})\s*(\d{2})\s*(\d{2})\s*[\u002D\u2010-\u2015\u2212\uFF0D]\s*(\d)',
    '(?<!\d)(\d{2})(\d{2})(\d{2})\s+(\d)(?=\d)',
    '(?<!\d)(\d{2})(\d{2})(\d{2})(?!\d)'
)
$candidates = @()
foreach ($pattern in $patterns) {
    foreach ($match in [regex]::Matches($text, $pattern)) {
        $front = $match.Groups[1].Value + $match.Groups[2].Value + $match.Groups[3].Value
        $candidates += [pscustomobject]@{ Front=$front; Marker=$match.Groups[4].Value }
    }
}
foreach ($candidate in $candidates) {
    $front = $candidate.Front
    $marker = $candidate.Marker
    $yy = [int]$front.Substring(0, 2)
    $month = [int]$front.Substring(2, 2)
    $day = [int]$front.Substring(4, 2)
    if ($marker -in @('1','2')) { $year = 1900 + $yy }
    elseif ($marker -in @('3','4')) { $year = 2000 + $yy }
    elseif ($yy -le ([datetime]::Today.Year % 100)) { $year = 2000 + $yy }
    else { $year = 1900 + $yy }
    try {
        $date = [datetime]::new($year, $month, $day)
        if ($date.Date -gt [datetime]::Today) { continue }
        $dob = $date.ToString('yyyy-MM-dd')
        if ($marker) {
            $sexMarkerSeen = $true
            if ($marker -in @('1','3')) { $sex = 1 }
            elseif ($marker -in @('2','4')) { $sex = 2 }
            else { $sex = $null }
        }
        break
    } catch { continue }
}
if (-not $sexMarkerSeen) { $sex = $labelSex }
if ($scaledPath -and (Test-Path -LiteralPath $scaledPath)) { Remove-Item -LiteralPath $scaledPath -Force }
[Console]::WriteLine((@{ dob=$dob; sex=$sex; sexManual=($sexMarkerSeen -and -not $sex) } | ConvertTo-Json -Compress))
