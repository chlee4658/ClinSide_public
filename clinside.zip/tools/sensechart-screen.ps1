param(
    [Parameter(Mandatory=$true)][ValidateSet('Snapshot','ReadArea')][string]$Mode,
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [int]$X=0,
    [int]$Y=0,
    [int]$Width=0,
    [int]$Height=0
)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
$virtual=[System.Windows.Forms.SystemInformation]::VirtualScreen
if($Mode -eq 'Snapshot'){
    $x=0;$y=0;$width=$virtual.Width;$height=$virtual.Height
}else{
    if($X -lt 0 -or $Y -lt 0 -or $Width -lt 1 -or $Height -lt 1 -or ($X+$Width) -gt $virtual.Width -or ($Y+$Height) -gt $virtual.Height){
        throw '화면 영역이 현재 모니터 범위를 벗어났습니다. 영역을 다시 지정해 주세요.'
    }
    $x=$X;$y=$Y;$width=$Width;$height=$Height
}
$bitmap=New-Object System.Drawing.Bitmap($width,$height,[System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$graphics=[System.Drawing.Graphics]::FromImage($bitmap)
try{
    $graphics.CopyFromScreen($virtual.Left+$x,$virtual.Top+$y,0,0,[System.Drawing.Size]::new($width,$height),[System.Drawing.CopyPixelOperation]::SourceCopy)
    $bitmap.Save($OutputPath,[System.Drawing.Imaging.ImageFormat]::Png)
}finally{
    $graphics.Dispose();$bitmap.Dispose()
}
if($Mode -eq 'ReadArea'){
    try { & (Join-Path $PSScriptRoot 'sensechart-ocr.ps1') -ImagePath $OutputPath }
    finally { Remove-Item -LiteralPath $OutputPath -Force -ErrorAction SilentlyContinue }
}
