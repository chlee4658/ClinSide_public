import json
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONTROL = ROOT / 'data' / 'clinside-server.json'


def main():
    if not CONTROL.is_file():
        print('ClinSide는 이미 종료되어 있습니다.')
        return 0
    try:
        info = json.loads(CONTROL.read_text(encoding='utf-8'))
        url = f"http://127.0.0.1:{int(info['port'])}/api/shutdown"
        request = urllib.request.Request(
            url,
            data=b'',
            headers={'X-ClinSide-Token': info['token']},
            method='POST',
        )
        with urllib.request.urlopen(request, timeout=3):
            pass
    except (OSError, ValueError, KeyError, urllib.error.URLError) as exc:
        print(f'ClinSide 종료 요청을 처리하지 못했습니다: {exc}')
        return 1
    for _ in range(30):
        if not CONTROL.exists():
            print('ClinSide를 종료했습니다.')
            return 0
        time.sleep(0.1)
    print('종료 요청을 보냈습니다.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
