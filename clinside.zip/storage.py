import sqlite3, json, uuid, datetime
from pathlib import Path

class Store:
    def __init__(self,path):
        self.path=Path(path)
        with self.connect() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS patients(id TEXT PRIMARY KEY, number TEXT UNIQUE, name TEXT NOT NULL, birthday TEXT, sex TEXT);
            CREATE TABLE IF NOT EXISTS visits(id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(id), kind TEXT NOT NULL CHECK(kind IN ('initial','followup')), date TEXT NOT NULL, data TEXT NOT NULL, updated TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS visits_patient ON visits(patient_id,date);
            CREATE TABLE IF NOT EXISTS migrations(source TEXT PRIMARY KEY);''')
    def connect(self):
        db=sqlite3.connect(self.path,timeout=15);db.row_factory=sqlite3.Row;db.execute('PRAGMA foreign_keys=ON');return db
    def patients(self,q=''):
        with self.connect() as db:
            rows=db.execute('''SELECT p.*,COUNT(v.id) AS visit_count,MAX(v.date) AS last_visit FROM patients p LEFT JOIN visits v ON p.id=v.patient_id WHERE instr(lower(p.name),lower(?))>0 OR instr(lower(COALESCE(p.number,'')),lower(?))>0 GROUP BY p.id ORDER BY last_visit DESC,p.name''',(q,q)).fetchall()
            return [dict(x) for x in rows]
    def visits(self,pid=None):
        with self.connect() as db:
            query='SELECT v.*,p.number,p.name,p.birthday,p.sex FROM visits v JOIN patients p ON p.id=v.patient_id'
            rows=db.execute(query+(' WHERE patient_id=?' if pid else '')+' ORDER BY date DESC,updated DESC',(pid,) if pid else ()).fetchall()
            return [self.entry(x) for x in rows]
    @staticmethod
    def entry(row):
        r=dict(row);r['data']=json.loads(r['data']);r['patient']={k:r.pop(k) for k in ('number','name','birthday','sex')};r['patient']['id']=r['patient_id'];return r
    def save(self,value,legacy=False):
        data=value.get('data');kind=value.get('kind','initial');pid=value.get('patient_id');rid=value.get('id')
        if not isinstance(data,dict) or kind not in ('initial','followup'):raise ValueError('올바른 기록이 아닙니다.')
        date=str(data.get('date') or '')
        if not legacy:
            try:datetime.date.fromisoformat(date)
            except ValueError:raise ValueError('방문일을 입력해주세요.')
        with self.connect() as db:
            old=db.execute('SELECT * FROM visits WHERE id=?',(rid,)).fetchone() if rid else None
            if rid and not old and not legacy:raise ValueError('기존 기록을 찾을 수 없습니다. 다시 불러와주세요.')
            if old:
                if pid and pid!=old['patient_id']:raise ValueError('기록의 환자를 바꿀 수 없습니다.')
                pid=old['patient_id']
                if kind!=old['kind']:raise ValueError('기록 종류를 바꿀 수 없습니다.')
            if pid:
                patient=db.execute('SELECT * FROM patients WHERE id=?',(pid,)).fetchone()
                if not patient:raise ValueError('환자를 찾을 수 없습니다.')
            else:
                if kind=='followup':raise ValueError('먼저 환자를 선택해주세요.')
                number=str(data.get('number') or '').strip();name=str(data.get('name') or '').strip()
                if not legacy and (not number or not name):raise ValueError('환자 이름과 차트번호를 입력해주세요.')
                patient=db.execute('SELECT * FROM patients WHERE number=?',(number,)).fetchone() if number else None
                if patient and (patient['name']!=name or (patient['birthday'] and data.get('birthday') and patient['birthday']!=data['birthday'])):
                    raise ValueError('같은 차트번호에 다른 환자 정보가 있습니다. 환자 검색에서 확인해주세요.')
                if not patient:
                    pid=uuid.uuid4().hex
                    db.execute('INSERT INTO patients VALUES(?,?,?,?,?)',(pid,number or None,name or '이름 미입력',data.get('birthday',''),data.get('sex','')))
                    patient=db.execute('SELECT * FROM patients WHERE id=?',(pid,)).fetchone()
                pid=patient['id']
            if not old and not legacy and kind=='initial' and db.execute("SELECT 1 FROM visits WHERE patient_id=? AND kind='initial'",(pid,)).fetchone():
                raise ValueError('이미 초진 차트가 있는 환자입니다. 환자 검색에서 불러오거나 재진 기록을 추가해주세요.')
            for key in ('number','name','birthday','sex'):data[key]=patient[key] or ''
            if kind=='followup' and not str(data.get('note','')).strip():raise ValueError('진료 내용을 입력해주세요.')
            rid=rid or uuid.uuid4().hex;updated=datetime.datetime.now(datetime.timezone.utc).isoformat()
            db.execute('INSERT INTO visits VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET date=excluded.date,data=excluded.data,updated=excluded.updated',(rid,pid,kind,date,json.dumps(data,ensure_ascii=False),updated))
        return next(r for r in self.visits(pid) if r['id']==rid)
    def save_followup_page(self,value):
        pid=value.get('patient_id');items=value.get('items')
        if not isinstance(items,list) or len(items)!=2:raise ValueError('재진 기록 두 칸을 확인해주세요.')
        saved=[None,None];seen=set()
        with self.connect() as db:
            patient=db.execute('SELECT * FROM patients WHERE id=?',(pid,)).fetchone()
            if not patient:raise ValueError('먼저 환자를 선택해주세요.')
            for i,item in enumerate(items):
                if not isinstance(item,dict) or not isinstance(item.get('data'),dict):raise ValueError('올바른 기록이 아닙니다.')
                data=item['data'];rid=item.get('id');note=data.get('note','');date=data.get('date','')
                if not isinstance(note,str) or not isinstance(date,str):raise ValueError('날짜와 기록 내용을 확인해주세요.')
                if not rid and not note.strip():continue
                if not note.strip():raise ValueError('저장된 기록 내용을 비울 수 없습니다.')
                try:datetime.date.fromisoformat(date)
                except ValueError:raise ValueError(f'{i+1}번째 기록의 날짜를 입력해주세요.')
                if rid:
                    old=db.execute('SELECT * FROM visits WHERE id=?',(rid,)).fetchone()
                    if not old or old['patient_id']!=pid or old['kind']!='followup':raise ValueError('환자와 재진 기록이 일치하지 않습니다.')
                    if rid in seen:raise ValueError('중복 기록을 저장할 수 없습니다.')
                rid=rid or uuid.uuid4().hex;seen.add(rid)
                entry={k:patient[k] or '' for k in ('number','name','birthday','sex')};entry.update(date=date,note=note)
                updated=datetime.datetime.now(datetime.timezone.utc).isoformat()
                db.execute('INSERT INTO visits VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET date=excluded.date,data=excluded.data,updated=excluded.updated',(rid,pid,'followup',date,json.dumps(entry,ensure_ascii=False),updated));saved[i]=rid
            if not any(saved):raise ValueError('진료 내용을 입력해주세요.')
        visits=self.visits(pid)
        return {'items':[next((r for r in visits if r['id']==rid),None) for rid in saved],'visits':visits}
    def migrate(self,folder):
        errors=[]
        for p in sorted(Path(folder).glob('*.json')):
            with self.connect() as db:
                if db.execute('SELECT 1 FROM migrations WHERE source=?',(p.name,)).fetchone():continue
            try:
                value=json.loads(p.read_text(encoding='utf-8'));self.save(value,legacy=True)
                with self.connect() as db:db.execute('INSERT OR IGNORE INTO migrations VALUES(?)',(p.name,))
            except (ValueError,TypeError,KeyError,OSError):errors.append(p.name)
        return errors
