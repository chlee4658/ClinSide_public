ClinSide for Windows (64-bit)

Extract this folder and double-click ClinSide-Windows.bat. No Python installation or administrator permission is needed. Use the ClinSide 종료 button in the top bar to stop the server.

The package intentionally excludes the existing clinic database and backups. A new empty data\clinic.sqlite3 is created on first run. Records entered on this PC are saved in this extracted folder.
