# ClinSide

`server.py`를 실행하면 로컬 주소 `127.0.0.1:8765`부터 사용 가능한 포트에서 브라우저가 열립니다. 진료 화면과 A4 출력은 이전 `leg-exam` 코드를 복사한 것이며, 초진·재진 기록은 이 폴더의 `data/clinic.sqlite3`에 저장됩니다. 상단 메뉴에서 각 도구의 본문을 전환합니다. 각 원본의 공개 웹페이지도 독립적으로 유지됩니다.

## Windows 공용 PC에서 실행

`ClinSide-Windows-Portable.zip`을 Windows PC에 복사해 압축을 푼 뒤, 안에 있는 `ClinSide-Windows.bat`을 더블클릭합니다. Python 설치나 관리자 권한 없이 실행하도록 공식 Windows 임베더블 Python 런타임을 함께 넣었습니다. 별도 패키지 설치도 필요하지 않습니다. 시작 파일은 서버를 보이지 않게 실행하므로 콘솔에서 `Ctrl+C`를 누를 필요가 없습니다.

사용을 마친 뒤에는 상단의 **ClinSide 종료** 버튼을 누르면 서버가 확인 질문 없이 종료됩니다. 브라우저가 열린 상태에서 바로 종료할 수 있고 별도 종료 파일은 필요하지 않습니다. `ClinSide-Stop-Windows.bat`도 예비 종료 방법으로 포함했습니다.

## GitHub에서 Windows 패키지 받기

개발 소스는 `chlee4658/clinside`에 push하고, Actions가 만든 최신 Windows 릴리스의 `ClinSide-Windows-Portable.zip`을 받아 `clinside.zip`으로 이름을 바꾸고 `chlee4658/ClinSide_public` 저장소의 파일을 교체합니다. 두 저장소에 대한 push는 수동으로 관리하며, 자동으로 비공개 소스가 공개 저장소로 복사되지는 않습니다. 공개 저장소의 `clinside.zip`이 Windows 업데이트 파일의 다운로드 대상입니다. 배포 ZIP에서는 다리 검사·기록, 예방접종 비교, 성장 분석 메뉴와 해당 프레임 모듈을 제외하며, 성장도표와 계산기 메뉴는 유지합니다.

공용 PC로 기존 환자 기록을 옮기지 않도록 배포 ZIP에는 `data/clinic.sqlite3`와 백업 파일을 포함하지 않았습니다. 첫 실행 때 빈 DB가 생성되고, 그 PC에서 입력한 기록은 압축을 푼 폴더의 `data/clinic.sqlite3`에 저장됩니다. 사용 후 해당 폴더와 DB 파일을 안전하게 관리하세요. ClinSide는 한 번에 한 PC에서만 실행해야 합니다.

상단 도구 메뉴 네 개는 드래그해 순서를 바꿀 수 있습니다. 키보드에서는 메뉴에 초점을 두고 `Alt + ←` 또는 `Alt + →`로 이동합니다. 순서는 해당 브라우저의 로컬 저장소에만 남으므로 다른 PC나 브라우저에서는 별도로 정렬해야 합니다. 환자 기록 DB와는 무관합니다.

## 두 저장소에 배포하기

1. 수정한 소스를 `chlee4658/clinside`에 push합니다.
2. Actions가 생성한 최신 GitHub 릴리스에서 `ClinSide-Windows-Portable.zip`을 내려받아 `clinside.zip`으로 이름을 바꿉니다.
3. Mac의 `clinside_dist` 폴더에서 기존 `clinside.zip`을 교체해 `chlee4658/ClinSide_public`에 push합니다.

공개 ZIP 다운로드 주소는 `https://github.com/chlee4658/ClinSide_public/raw/refs/heads/main/clinside.zip`입니다. 업데이트 파일은 이 주소에서 최신 ZIP을 받습니다. 릴리스 ZIP을 만들기만 해서는 Windows PC의 업데이트 파일이 받는 ZIP이 바뀌지 않으므로 배포 저장소에도 교체해야 합니다.

## ClinSide 업데이트

- Windows: 기존 ClinSide 폴더의 `Update_ClinSide_Git.bat`을 실행합니다. 이 파일은 `ClinSide_public`의 main 브랜치에서 최신 `clinside.zip`을 내려받아 코드와 런타임을 갱신하고, 업데이트 전 코드 백업을 만듭니다. `data`와 `backups`는 보존하며 Git이나 별도 인증 도구는 필요하지 않습니다.
- macOS: ClinSide 폴더에서 `Update_ClinSide_Git.command`를 실행합니다. 최초 1회 실행 권한이 필요하면 터미널에서 `chmod +x Update_ClinSide_Git.command`를 실행하세요. GitHub CLI(`gh`)를 설치하고 `gh auth login`으로 비공개 저장소에 로그인해야 합니다.
- 두 업데이트 파일은 로컬 환자 데이터, 백업, Python 런타임을 업데이트 대상에서 제외합니다. macOS 스크립트는 코드 파일 백업을 업데이트 전에 만듭니다.

## 개발자 전용 Windows 버전

`chlee4658/clinside`의 private GitHub Release에서 `ClinSide-Windows-Portable.zip`을 내려받으면 개발자 버전으로 실행할 수 있습니다. 이 ZIP은 Windows 실행 파일과 Python 런타임을 포함하므로 소스 폴더만 복사하는 방식과 다릅니다. 개발자용 업데이트는 같은 private Release의 `Update_ClinSide_Dev.bat`과 `Update_ClinSide_Dev.ps1`을 ClinSide 폴더에 함께 두고 실행합니다. 이 업데이트에는 GitHub CLI(`gh`) 설치와 `gh auth login` 로그인이 필요합니다. 공개 사용자는 계속 `ClinSide_public`의 `clinside.zip`과 `Update_ClinSide_Git.bat`을 사용합니다.

## 구성과 연결 상태

| 메뉴 | 현재 방식 | 연결 조건 |
| --- | --- | --- |
| 다리 검사·기록 | 이 폴더 안의 로컬 서버와 SQLite | 오프라인 가능 |
| 예방접종 비교 | `embedded/vaxcompare/`에 복사한 공개 화면 빌드의 본문 | 접종 비교 화면은 로컬 제공. OCR의 Tesseract 언어 모델은 인터넷에서 내려받을 수 있음. 학교 양식 AI 분석은 로컬 API가 없어 공개 사이트에서만 이용 |
| 성장 분석 | `embedded/growth/`에 복사한 화면·계산 JS·자료·Chart.js | 기본 계산과 그래프는 로컬 제공. 결제·AI 상세 리포트는 공개 사이트에서만 이용 |
| 성장도표 | 사용자가 제공한 `growth-percentiles.html`의 ClinSide 화면 복사본 | 기준 자료와 계산식은 파일에 포함되어 있으며 오프라인 동작 |

두 도구는 같은 로컬 서버에서 제공하는 **복사본 화면**을 ClinSide의 본문 프레임에 표시합니다. 공개 사이트를 프레임에 넣지 않으며, 외부 사이트의 프레임 허용 여부에 의존하지 않습니다. 원본 프로젝트를 수정하지 않았습니다. 원본이 변경되면 복사본은 자동 갱신되지 않으므로 화면 자원과 계산 코드를 다시 동기화해야 합니다. 로컬 환자 DB의 내용을 온라인 도구로 자동 전달하지 않습니다. 도구별 브라우저 보관함도 별개입니다. 센스차트 직접 연동은 없습니다.

성장도표의 **영역 지정** 버튼은 ClinSide 로컬 서버가 Windows 화면을 한 번 캡처해 보여줍니다. 필요한 영역을 지정한 뒤 환자별로 **정보 가져오기** 버튼을 누르면 해당 위치를 한 번 캡처해 Windows 기본 OCR로 읽습니다. 브라우저 화면 공유를 사용하지 않습니다. 한국어 OCR 언어 기능이 Windows에 설치되어 있어야 합니다. 주민등록번호 전체는 저장하거나 OCR 결과로 반환하지 않으며, 생년월일과 성별만 화면에 적용합니다. 성별 코드는 1·3=남아, 2·4=여아로 판정하고 그 외 숫자는 직접 선택하도록 합니다. 캡처 파일은 로컬 임시 파일에서 처리 후 삭제되며 외부 서버로 전송되지 않습니다. 생년월일·성별은 언제든 수동 입력 및 수정할 수 있습니다.\n\n성장도표 원본은 `embedded/chart/original.html`에 바이트 그대로 보관했습니다. 표시용 `embedded/chart/index.html`에는 ClinSide 안에서 입력 영역이 먼저 보이도록 하는 CSS와, 원본에서 ‘나이 입력’ 버튼이 생년월일 탭으로 이동하던 연결 오류의 수정만 적용했습니다. 계산 자료와 백분위 계산식은 바꾸지 않았습니다.

환자 연결을 확장할 때 쓸 수 있는 공통 값은 차트번호·이름·생년월일·성별입니다. 현재 `leg-exam`의 `patients` 테이블은 이 값을 갖고 있습니다. 성장 분석은 이름·생년월일 외에 측정일과 키·몸무게가 필요하고, 예방접종 비교는 생년월일과 접종별 날짜·차수가 필요합니다. 두 공개 도구의 브라우저 보관함은 로컬 진료 DB와 공유되지 않습니다. 따라서 이 초안은 환자를 온라인 도구에 자동 입력하거나 기록을 합치지 않습니다.

## 기존 진료 기록 이전

실제 데이터를 옮기려면 서버를 종료하고 다음 명령을 명시적으로 실행합니다.

```text
python import_legacy.py "기존 leg-exam/clinic.sqlite3의 전체 경로"
```

스크립트는 원본을 읽기 전용으로 열고 `backups/`에 원본 스냅샷을 만든 뒤 새 DB에 복사합니다. 새 DB에 환자 기록이 있으면 덮어쓰지 않습니다. 새 DB가 비어 있어도 그 상태를 백업합니다. 이전 전후에 `data/clinic.sqlite3`를 포함한 전체 폴더를 별도로 백업하세요.

