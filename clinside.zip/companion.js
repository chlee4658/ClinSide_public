(()=>{
const frame=document.querySelector('#content');
const chartButton=document.querySelector('#chart-button');
const calcButton=document.querySelector('#calculator-button');
const menu=document.querySelector('#calculator-menu');
const dropdown=document.querySelector('.calculator-dropdown');
function closeMenu(){menu.hidden=true;calcButton.setAttribute('aria-expanded','false')}
function showChart(){frame.src='embedded/chart/index.html';frame.title='성장도표';chartButton.classList.add('current');calcButton.classList.remove('current');closeMenu()}
function showCalculator(item,button){frame.src=item.url;frame.title=item.title;chartButton.classList.remove('current');calcButton.classList.add('current');menu.querySelectorAll('button').forEach(el=>el.classList.toggle('current',el===button));closeMenu()}
chartButton.addEventListener('click',showChart);
document.querySelector('.brand').addEventListener('click',event=>{event.preventDefault();showChart()});
calcButton.addEventListener('click',event=>{event.stopPropagation();menu.hidden=!menu.hidden;calcButton.setAttribute('aria-expanded',String(!menu.hidden))});
document.addEventListener('click',event=>{if(!dropdown.contains(event.target))closeMenu()});
calcButton.addEventListener('keydown',event=>{if(event.key==='Escape')closeMenu()});
async function loadCalculators(){
 menu.replaceChildren();
 try{
  const response=await fetch('/api/calculators');if(!response.ok)throw new Error();
  const items=await response.json();
  if(!items.length){const note=document.createElement('div');note.className='empty';note.textContent='calculators 폴더에 HTML 계산기를 넣으면 여기에 표시됩니다.';menu.append(note);return}
  for(const item of items){const button=document.createElement('button');button.type='button';button.role='menuitem';button.textContent=item.title;button.addEventListener('click',()=>showCalculator(item,button));menu.append(button)}
 }catch{const note=document.createElement('div');note.className='empty';note.textContent='계산기 목록을 불러오지 못했습니다.';menu.append(note)}
}
const shutdownButton=document.querySelector('#shutdown-button');
shutdownButton.addEventListener('click',async()=>{shutdownButton.disabled=true;shutdownButton.textContent='종료 중…';try{const token=await fetch('/api/shutdown-token').then(r=>r.json());await fetch('/api/shutdown',{method:'POST',headers:{'X-ClinSide-Token':token.token}});shutdownButton.textContent='ClinSide가 종료되었습니다.'}catch{shutdownButton.disabled=false;shutdownButton.textContent='ClinSide 종료'}});
loadCalculators();
})();
