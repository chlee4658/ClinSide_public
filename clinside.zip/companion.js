(()=>{
const workspace=document.createElement('div');workspace.id='leg-workspace';
const top=document.querySelector('.companion-top');top.after(workspace);
const legHeader=document.querySelector('.site-header'),shutdownButton=document.querySelector('#shutdown-app');top.append(legHeader,shutdownButton);
for(const selector of ['main','dialog']){const el=document.querySelector(selector);if(el)workspace.append(el)}
const panels={leg:workspace};
function makePanel(name,src,label){
 const section=document.createElement('section');section.className='tool-panel';section.id='tool-'+name.replace(/[^a-zA-Z0-9_-]/g,'-');section.hidden=true;
 const frame=document.createElement('iframe');frame.title=label;frame.src=src;frame.className='tool-frame';frame.loading='lazy';section.append(frame);
 workspace.after(section);panels[name]=section;
}


makePanel('chart','/embedded/chart/index.html','성장도표');
makePanel('phrases','/phrases.html','문구 보관함');
const calculatorDropdown=top.querySelector('.calculator-dropdown');
const calculatorButton=top.querySelector('#calculator-menu');
const calculatorSubmenu=top.querySelector('#calculator-submenu');
function closeCalculatorMenu(){calculatorSubmenu.hidden=true;calculatorButton.setAttribute('aria-expanded','false')}
let phraseLoaded=false;
function show(name){if(name==='phrases'&&!phraseLoaded){panels.phrases.querySelector('iframe').src='/phrases.html?fresh='+Date.now();phraseLoaded=true}for(const [key,panel] of Object.entries(panels))panel.hidden=key!==name;legHeader.hidden=name!=='leg';document.querySelectorAll('[data-view]').forEach(button=>button.classList.toggle('current',button.dataset.view===name));calculatorButton.classList.toggle('current',name.startsWith('calculator:'));calculatorSubmenu.querySelectorAll('.calculator-subitem').forEach(button=>button.classList.toggle('current',button.dataset.panel===name));closeCalculatorMenu();window.scrollTo(0,0)}
const toolNav=top.querySelector('nav[aria-label="통합 도구"]');
const navButtons=[...toolNav.querySelectorAll('button[data-view]')];
const navOrderKey='clinside:nav-order:v1';
const defaultOrder=navButtons.map(button=>button.dataset.view);
const readOrder=()=>[...toolNav.querySelectorAll('button[data-view]')].map(button=>button.dataset.view);
function applyOrder(order){for(const view of order){const button=navButtons.find(item=>item.dataset.view===view);if(button)toolNav.append(button)}const chart=navButtons.find(item=>item.dataset.view==='chart');toolNav.append(calculatorDropdown)}
function saveOrder(){try{localStorage.setItem(navOrderKey,JSON.stringify(readOrder()))}catch{}}
try{const saved=JSON.parse(localStorage.getItem(navOrderKey));if(Array.isArray(saved)&&saved.length===defaultOrder.length&&new Set(saved).size===defaultOrder.length&&saved.every(view=>defaultOrder.includes(view)))applyOrder(saved)}catch{}
let dragged=null,startOrder=null,dropped=false,suppressClickUntil=0;
toolNav.addEventListener('dragstart',event=>{
 const button=event.target.closest('button[data-view]');if(!button)return;
 dragged=button;startOrder=readOrder();dropped=false;
 event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',button.dataset.view);
 requestAnimationFrame(()=>button.classList.add('is-dragging'));
});
toolNav.addEventListener('dragover',event=>{
 if(!dragged)return;
 event.preventDefault();event.dataTransfer.dropEffect='move';
 const target=event.target.closest('button[data-view]');if(!target||target===dragged)return;
 const halfway=target.getBoundingClientRect().left+target.getBoundingClientRect().width/2;
 toolNav.insertBefore(dragged,event.clientX<halfway?target:target.nextSibling);
});
toolNav.addEventListener('drop',event=>{
 if(!dragged)return;
 event.preventDefault();dropped=true;const chart=navButtons.find(item=>item.dataset.view==='chart');toolNav.append(calculatorDropdown);saveOrder();suppressClickUntil=Date.now()+250;
});
toolNav.addEventListener('dragend',()=>{
 if(dragged&&!dropped&&startOrder)applyOrder(startOrder);
 dragged?.classList.remove('is-dragging');dragged=null;startOrder=null;
});
toolNav.addEventListener('click',event=>{if(Date.now()<suppressClickUntil){event.preventDefault();event.stopPropagation()}},true);
for(const button of navButtons){
 button.draggable=true;button.title='드래그해 메뉴 순서 변경 · Alt + ←/→로도 이동';
 button.addEventListener('click',()=>show(button.dataset.view));
 button.addEventListener('keydown',event=>{
  if(!event.altKey||!['ArrowLeft','ArrowRight'].includes(event.key))return;
  event.preventDefault();const order=readOrder(),index=order.indexOf(button.dataset.view),next=index+(event.key==='ArrowLeft'?-1:1);
  if(next<0||next>=order.length)return;
  [order[index],order[next]]=[order[next],order[index]];applyOrder(order);saveOrder();button.focus();
 });
}
calculatorButton.addEventListener('click',event=>{event.stopPropagation();const open=calculatorSubmenu.hidden;closeCalculatorMenu();if(open){calculatorSubmenu.hidden=false;calculatorButton.setAttribute('aria-expanded','true');calculatorSubmenu.querySelector('.calculator-subitem')?.focus()}});
calculatorButton.addEventListener('keydown',event=>{if(event.key==='Escape')closeCalculatorMenu()});
document.addEventListener('click',event=>{if(!calculatorDropdown.contains(event.target))closeCalculatorMenu()});
async function loadCalculators(){
 calculatorSubmenu.replaceChildren();
 try{
  const response=await fetch('/api/calculators');if(!response.ok)throw Error('목록을 불러오지 못했습니다.');
  const items=await response.json();
  if(!items.length){const empty=document.createElement('div');empty.className='calculator-empty';empty.textContent='calculators 폴더에 HTML 파일을 추가하세요.';calculatorSubmenu.append(empty);return}
  items.forEach(item=>{const key='calculator:'+item.path,button=document.createElement('button');button.type='button';button.className='calculator-subitem';button.setAttribute('role','menuitem');button.dataset.panel=key;button.textContent=item.title;button.addEventListener('click',()=>{if(!panels[key])makePanel(key,item.url,item.title);show(key)});calculatorSubmenu.append(button)})
 }catch{const error=document.createElement('div');error.className='calculator-empty';error.textContent='계산기 목록을 불러오지 못했습니다.';calculatorSubmenu.append(error)}
}
loadCalculators();
document.querySelector('.companion-brand').addEventListener('click',event=>{event.preventDefault();history.replaceState(null,'',location.pathname+location.search);show('chart')});
show('chart');

})();
