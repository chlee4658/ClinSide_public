@echo off
setlocal
cd /d "%~dp0"
"runtime\python.exe" stop_clinside.py
pause
