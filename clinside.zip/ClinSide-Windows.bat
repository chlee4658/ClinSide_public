@echo off
setlocal
cd /d "%~dp0"
if not exist "runtime\python.exe" (
    echo ClinSide portable runtime is missing. Extract the complete ZIP first.
    exit /b 1
)
"runtime\python.exe" launch_clinside.py
