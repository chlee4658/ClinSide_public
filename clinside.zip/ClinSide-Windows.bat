@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

if exist "runtime\python.exe" (
    "runtime\python.exe" launch_clinside.py
    set "RESULT=!errorlevel!"
    goto :done
)

where py >nul 2>&1
if not errorlevel 1 (
    py -3 launch_clinside.py
    set "RESULT=!errorlevel!"
    goto :done
)

where python >nul 2>&1
if not errorlevel 1 (
    python launch_clinside.py
    set "RESULT=!errorlevel!"
    goto :done
)

echo The bundled Python runtime is missing from this ClinSide folder.
echo Run the developer updater inside your existing ClinSide folder, or restore the full Windows package.
pause
exit /b 1

:done
if "%RESULT%"=="0" exit /b 0
echo.
echo ClinSide did not start. Diagnostic output:
if exist "data\clinside-server.log" type "data\clinside-server.log"
pause
exit /b %RESULT%
